# Neon Survivor v0.4.0 — Full 2D Rebuild

Bu sürüm gerçek Godot 2D node yapısına geçirilmiştir.

## Dünya / oyun sistemi
- `Node2D` arena
- `CharacterBody2D` oyuncu
- `CharacterBody2D` düşmanlar
- `AnimatedSprite2D` karakter ve düşman animasyonları
- `Area2D + CollisionShape2D` enerji bıçakları
- `Area2D` XP kristalleri
- `CPUParticles2D` vuruş / ölüm efektleri
- Mobil joystick
- Otomatik saldırı
- Hasar rakamları ve kritik vuruş
- XP / level sistemi
- 3 seçenekli level-up paneli
- 6 upgrade türü
- Spider / Drone / Brute düşmanları
- 60. saniyede boss
- Boss HP barı
- Ölüm sonrası run reset

## GitHub
Çalışan `.github/workflows/android-build.yml` dosyanızı DEĞİŞTİRMEYİN.

Repo içindeki eski Neon Survivor ZIP'ini silip yalnızca:
`neon-survivor-v0.4.0.zip`
dosyasını bırakın.

Workflow mevcut ZIP çıkarma sistemiyle bu projeyi derlemelidir.
