extends Node2D

const ENEMY_SCENE = preload("res://scenes/enemy.tscn")
const BLADE_SCENE = preload("res://scenes/blade.tscn")
const GEM_SCENE = preload("res://scenes/gem.tscn")

@onready var world = $World
@onready var effects = $World/../World/../World if false else $World
@onready var player = $World/Player

@onready var level_label = $CanvasLayer/TopHud/Level
@onready var xp_fill = $CanvasLayer/TopHud/XPFill
@onready var timer_label = $CanvasLayer/TopHud/Timer
@onready var kills_label = $CanvasLayer/TopHud/Kills
@onready var hp_fill = $CanvasLayer/TopHud/HPFill
@onready var status_label = $CanvasLayer/TopHud/Status
@onready var boss_panel = $CanvasLayer/TopHud/BossPanel
@onready var boss_fill = $CanvasLayer/TopHud/BossPanel/Back/Fill
@onready var blade_level = $CanvasLayer/BottomHud/BladeCard/BladeLevel
@onready var core_level = $CanvasLayer/BottomHud/CoreCard/CoreLevel
@onready var joy_base = $CanvasLayer/JoystickBase
@onready var joy_knob = $CanvasLayer/JoystickKnob
@onready var upgrade_panel = $CanvasLayer/UpgradePanel
@onready var upgrade_buttons = [
	$CanvasLayer/UpgradePanel/Button1,
	$CanvasLayer/UpgradePanel/Button2,
	$CanvasLayer/UpgradePanel/Button3
]

var enemies = []
var blades = []
var gems = []

var elapsed = 0.0
var spawn_clock = 0.0
var kills = 0
var level = 1
var xp = 0
var xp_need = 8

var blade_damage = 11.0
var blade_upgrade_level = 1
var core_upgrade_level = 1
var magnet_radius = 190.0
var crit_chance = 0.10

var boss_spawned = false
var upgrade_open = false

var touch_id = -1
var joystick_active = false
var joystick_center = Vector2(99.0, 995.0)
var joystick_pos = Vector2(99.0, 995.0)

var arena_size = Vector2(696.0, 1022.0)

func _ready():
	player.set_arena_size(arena_size)
	player.hp_changed.connect(_on_player_hp_changed)
	player.died.connect(_on_player_died)

	for button in upgrade_buttons:
		button.pressed.connect(_on_upgrade_button_pressed.bind(button))

	_spawn_initial_blades()
	_update_hud()
	status_label.text = "2D ARENA ONLINE"

func _process(delta):
	if upgrade_open:
		player.set_move_input(Vector2.ZERO)
		return

	elapsed += delta
	spawn_clock += delta

	_update_player_input()

	var spawn_delay = max(0.30, 0.92 - elapsed * 0.0045)
	while spawn_clock >= spawn_delay:
		spawn_clock -= spawn_delay
		_spawn_enemy(false)

	if elapsed >= 60.0 and not boss_spawned:
		boss_spawned = true
		_spawn_enemy(true)

	_update_hud()

func _spawn_initial_blades():
	for i in range(4):
		_add_blade(TAU * float(i) / 4.0)

func _add_blade(angle):
	var blade = BLADE_SCENE.instantiate()
	blade.setup(player, angle)
	blade.damage = blade_damage
	blade.crit_chance = crit_chance
	blade.hit_landed.connect(_on_blade_hit)
	world.add_child(blade)
	blades.append(blade)

func _update_player_input():
	var direction = Vector2.ZERO

	if joystick_active:
		direction = ((joystick_pos - joystick_center) / 76.0).limit_length(1.0)

	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		direction.x -= 1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		direction.x += 1.0
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		direction.y -= 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		direction.y += 1.0

	player.set_move_input(direction.limit_length(1.0))

func _spawn_enemy(is_boss):
	var enemy = ENEMY_SCENE.instantiate()
	var kind = 3 if is_boss else _roll_enemy_kind()
	enemy.configure(kind, player, elapsed)
	enemy.died.connect(_on_enemy_died)
	enemy.contact_damage.connect(_on_enemy_contact_damage)
	enemy.hp_ratio_changed.connect(_on_enemy_hp_ratio)
	world.add_child(enemy)

	var size = arena_size
	var margin = 55.0 if not is_boss else 85.0
	var side = randi() % 4

	if side == 0:
		enemy.position = Vector2(randf_range(30.0, size.x - 30.0), -margin)
	elif side == 1:
		enemy.position = Vector2(size.x + margin, randf_range(30.0, size.y - 30.0))
	elif side == 2:
		enemy.position = Vector2(randf_range(30.0, size.x - 30.0), size.y + margin)
	else:
		enemy.position = Vector2(-margin, randf_range(30.0, size.y - 30.0))

	enemies.append(enemy)

	if is_boss:
		boss_panel.visible = true
		boss_fill.size.x = 170.0
		status_label.text = "BOSS INBOUND"

func _roll_enemy_kind():
	var roll = randf()
	if roll > 0.84:
		return 2
	if roll > 0.58:
		return 1
	return 0

func _on_enemy_contact_damage(amount):
	player.take_damage(amount)

func _on_enemy_hp_ratio(ratio, was_boss):
	if was_boss:
		boss_fill.size.x = 170.0 * ratio

func _on_enemy_died(enemy, world_position, gem_value, was_boss):
	enemies.erase(enemy)
	kills += 12 if was_boss else 1

	if was_boss:
		boss_panel.visible = false
		status_label.text = "BOSS DESTROYED"

	_spawn_gem(world_position, gem_value)
	_spawn_burst(world_position, Color(1.0, 0.18, 0.16, 1.0), 22 if was_boss else 10)

func _spawn_gem(world_position, value):
	var gem = GEM_SCENE.instantiate()
	gem.setup(player, value, magnet_radius)
	gem.global_position = world_position
	gem.collected.connect(_on_gem_collected)
	world.add_child(gem)
	gems.append(gem)

func _on_gem_collected(value):
	xp += value

	for gem in gems.duplicate():
		if not is_instance_valid(gem):
			gems.erase(gem)

	if xp >= xp_need:
		xp -= xp_need
		level += 1
		xp_need = int(round(float(xp_need) * 1.28 + 2.0))
		_open_upgrade_panel()

func _on_blade_hit(world_position, amount, critical):
	_spawn_damage_number(world_position, amount, critical)
	_spawn_burst(world_position, Color(0.30, 0.82, 1.0, 1.0), 5)

func _spawn_damage_number(world_position, amount, critical):
	var label = Label.new()
	label.text = str(int(round(amount)))
	label.position = world_position + Vector2(-28.0, -30.0)
	label.size = Vector2(56.0, 34.0)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", 27 if critical else 20)
	label.add_theme_color_override(
		"font_color",
		Color(1.0, 0.82, 0.20, 1.0) if critical else Color(1.0, 0.42, 0.72, 1.0)
	)
	world.add_child(label)

	var tween = create_tween()
	tween.set_parallel(true)
	tween.tween_property(label, "position", label.position + Vector2(0.0, -46.0), 0.5)
	tween.tween_property(label, "modulate:a", 0.0, 0.5)
	tween.set_parallel(false)
	tween.tween_callback(label.queue_free)

func _spawn_burst(world_position, color, amount):
	var particles = CPUParticles2D.new()
	particles.position = world_position
	particles.amount = amount
	particles.lifetime = 0.42
	particles.one_shot = true
	particles.explosiveness = 0.9
	particles.direction = Vector2(1.0, 0.0)
	particles.spread = 180.0
	particles.initial_velocity_min = 75.0
	particles.initial_velocity_max = 190.0
	particles.gravity = Vector2.ZERO
	particles.scale_amount_min = 2.0
	particles.scale_amount_max = 5.0
	particles.color = color
	world.add_child(particles)
	particles.emitting = true

	var timer = get_tree().create_timer(0.8)
	timer.timeout.connect(particles.queue_free)

func _open_upgrade_panel():
	upgrade_open = true
	upgrade_panel.visible = true
	status_label.text = "CHOOSE EVOLUTION"

	for enemy in enemies:
		if is_instance_valid(enemy):
			enemy.set_physics_process(false)
	for blade in blades:
		if is_instance_valid(blade):
			blade.set_physics_process(false)
	for gem in gems:
		if is_instance_valid(gem):
			gem.set_physics_process(false)

	var choices = [
		{"title":"ENERGY BLADES", "desc":"+25% DAMAGE", "kind":0},
		{"title":"PHASE STEP", "desc":"+10% MOVE SPEED", "kind":1},
		{"title":"MAGNET CORE", "desc":"+45 PICKUP RANGE", "kind":2},
		{"title":"NANO REPAIR", "desc":"+20 MAX HP + HEAL", "kind":3},
		{"title":"EXTRA BLADE", "desc":"+1 ORBITING BLADE", "kind":4},
		{"title":"CRITICAL CORE", "desc":"+8% CRIT CHANCE", "kind":5}
	]
	choices.shuffle()

	for i in range(3):
		var choice = choices[i]
		var button = upgrade_buttons[i]
		button.text = "%s\n%s" % [choice["title"], choice["desc"]]
		button.set_meta("upgrade_kind", choice["kind"])

func _on_upgrade_button_pressed(button):
	if not upgrade_open:
		return

	var kind = int(button.get_meta("upgrade_kind"))

	if kind == 0:
		blade_damage *= 1.25
		blade_upgrade_level += 1
	elif kind == 1:
		player.speed *= 1.10
		core_upgrade_level += 1
	elif kind == 2:
		magnet_radius += 45.0
		for gem in gems:
			if is_instance_valid(gem):
				gem.magnet_radius = magnet_radius
	elif kind == 3:
		player.add_max_hp(20.0)
		player.heal(25.0)
	elif kind == 4:
		if blades.size() < 8:
			_add_blade(randf() * TAU)
			blade_upgrade_level += 1
	elif kind == 5:
		crit_chance = min(0.60, crit_chance + 0.08)
		core_upgrade_level += 1

	for blade in blades:
		if is_instance_valid(blade):
			blade.damage = blade_damage
			blade.crit_chance = crit_chance
			blade.set_physics_process(true)

	for enemy in enemies:
		if is_instance_valid(enemy):
			enemy.set_physics_process(true)

	for gem in gems:
		if is_instance_valid(gem):
			gem.set_physics_process(true)

	upgrade_panel.visible = false
	upgrade_open = false
	status_label.text = "EVOLUTION APPLIED"
	_spawn_burst(player.global_position, Color(0.25, 1.0, 0.74, 1.0), 20)

func _on_player_hp_changed(current_hp, maximum_hp):
	hp_fill.size.x = 260.0 * clamp(current_hp / maximum_hp, 0.0, 1.0)

func _on_player_died():
	status_label.text = "SYSTEM REBOOT"
	_restart_run()

func _restart_run():
	for enemy in enemies.duplicate():
		if is_instance_valid(enemy):
			enemy.queue_free()
	for blade in blades.duplicate():
		if is_instance_valid(blade):
			blade.queue_free()
	for gem in gems.duplicate():
		if is_instance_valid(gem):
			gem.queue_free()

	enemies.clear()
	blades.clear()
	gems.clear()

	elapsed = 0.0
	spawn_clock = 0.0
	kills = 0
	level = 1
	xp = 0
	xp_need = 8
	blade_damage = 11.0
	blade_upgrade_level = 1
	core_upgrade_level = 1
	magnet_radius = 190.0
	crit_chance = 0.10
	boss_spawned = false
	boss_panel.visible = false

	player.reset_player()
	player.position = Vector2(360.0, 510.0)
	_spawn_initial_blades()
	_update_hud()

func _update_hud():
	level_label.text = "LV %d" % level
	kills_label.text = "KILL %d" % kills
	blade_level.text = "Lv.%d" % blade_upgrade_level
	core_level.text = "Lv.%d" % core_upgrade_level

	var minutes = int(elapsed / 60.0)
	var seconds = int(elapsed) % 60
	timer_label.text = "%02d:%02d" % [minutes, seconds]

	xp_fill.size.x = 190.0 * clamp(float(xp) / float(max(1, xp_need)), 0.0, 1.0)

func _input(event):
	if upgrade_open:
		return

	if event is InputEventScreenTouch:
		if event.pressed:
			if event.position.x < 330.0 and event.position.y > 760.0:
				touch_id = event.index
				joystick_active = true
				joystick_center = event.position
				joystick_pos = event.position
				joy_base.position = joystick_center - joy_base.size * 0.5
				joy_knob.position = joystick_center - joy_knob.size * 0.5
		elif event.index == touch_id:
			touch_id = -1
			joystick_active = false
			_reset_joystick()

	elif event is InputEventScreenDrag:
		if event.index == touch_id:
			joystick_pos = joystick_center + (event.position - joystick_center).limit_length(76.0)
			joy_knob.position = joystick_pos - joy_knob.size * 0.5

func _reset_joystick():
	joystick_center = Vector2(99.0, 995.0)
	joystick_pos = joystick_center
	joy_base.position = Vector2(34.0, 930.0)
	joy_knob.position = Vector2(72.0, 968.0)
