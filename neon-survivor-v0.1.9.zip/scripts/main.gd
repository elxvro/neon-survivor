extends Node2D

var view_size := Vector2(720.0, 1280.0)
var top_h := 110.0
var bottom_h := 150.0

var player := Vector2.ZERO
var player_radius := 22.0
var player_speed := 310.0
var hp := 100.0
var max_hp := 100.0

var elapsed := 0.0
var spawn_clock := 0.0
var kills := 0
var level := 1
var xp := 0
var xp_need := 8

var enemy_pos: Array[Vector2] = []
var enemy_hp: Array[float] = []
var enemy_max_hp: Array[float] = []
var enemy_speed: Array[float] = []
var enemy_radius: Array[float] = []
var enemy_hit_cd: Array[float] = []

var gems: Array[Vector2] = []
var blades: Array[float] = [0.0, PI * 0.5, PI, PI * 1.5]

var joystick_active := false
var joystick_id := -1
var joystick_center := Vector2.ZERO
var joystick_knob := Vector2.ZERO

var ui_font: Font

func _ready() -> void:
	ui_font = ThemeDB.fallback_font
	view_size = get_viewport_rect().size
	player = Vector2(view_size.x * 0.5, view_size.y * 0.54)
	_reset_joystick()
	queue_redraw()

func _process(delta: float) -> void:
	view_size = get_viewport_rect().size
	elapsed += delta
	spawn_clock += delta

	_move_player(delta)

	var spawn_delay := max(0.32, 0.95 - elapsed * 0.004)
	while spawn_clock >= spawn_delay:
		spawn_clock -= spawn_delay
		_spawn_enemy()

	for i in range(blades.size()):
		blades[i] += delta * 2.8

	_update_enemies(delta)
	_update_gems(delta)
	queue_redraw()

func _arena_top() -> float:
	return top_h

func _arena_bottom() -> float:
	return view_size.y - bottom_h

func _move_player(delta: float) -> void:
	var direction := Vector2.ZERO

	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		direction.x -= 1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		direction.x += 1.0
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		direction.y -= 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		direction.y += 1.0

	if joystick_active:
		var joy := (joystick_knob - joystick_center) / 78.0
		if joy.length() > 0.12:
			direction = joy.limit_length(1.0)

	if direction.length() > 1.0:
		direction = direction.normalized()

	player += direction * player_speed * delta
	player.x = clamp(player.x, 34.0, view_size.x - 34.0)
	player.y = clamp(player.y, _arena_top() + 34.0, _arena_bottom() - 34.0)

func _spawn_enemy() -> void:
	var side := randi() % 4
	var pos := Vector2.ZERO

	if side == 0:
		pos = Vector2(randf_range(0.0, view_size.x), _arena_top() - 35.0)
	elif side == 1:
		pos = Vector2(view_size.x + 35.0, randf_range(_arena_top(), _arena_bottom()))
	elif side == 2:
		pos = Vector2(randf_range(0.0, view_size.x), _arena_bottom() + 35.0)
	else:
		pos = Vector2(-35.0, randf_range(_arena_top(), _arena_bottom()))

	var heavy := randf() > 0.82
	var radius := 30.0 if heavy else 18.0
	var e_hp := (48.0 if heavy else 18.0) + elapsed * 0.06
	var speed := 56.0 if heavy else 86.0

	enemy_pos.append(pos)
	enemy_hp.append(e_hp)
	enemy_max_hp.append(e_hp)
	enemy_speed.append(speed)
	enemy_radius.append(radius)
	enemy_hit_cd.append(0.0)

func _update_enemies(delta: float) -> void:
	for i in range(enemy_pos.size() - 1, -1, -1):
		var pos := enemy_pos[i]
		var direction := player - pos

		if direction.length() > 0.1:
			pos += direction.normalized() * enemy_speed[i] * delta

		enemy_hit_cd[i] = max(0.0, enemy_hit_cd[i] - delta)

		for angle in blades:
			var blade_pos := player + Vector2(cos(angle), sin(angle)) * 108.0
			if blade_pos.distance_to(pos) <= enemy_radius[i] + 16.0 and enemy_hit_cd[i] <= 0.0:
				enemy_hp[i] -= 10.0 + float(level)
				enemy_hit_cd[i] = 0.20
				break

		if pos.distance_to(player) <= enemy_radius[i] + player_radius:
			hp -= 18.0 * delta
			var push := (pos - player).normalized()
			if push.length() > 0.0:
				pos += push * 24.0 * delta

		enemy_pos[i] = pos

		if enemy_hp[i] <= 0.0:
			kills += 1
			gems.append(pos)
			_remove_enemy(i)

	if hp <= 0.0:
		_restart_run()

func _remove_enemy(index: int) -> void:
	enemy_pos.remove_at(index)
	enemy_hp.remove_at(index)
	enemy_max_hp.remove_at(index)
	enemy_speed.remove_at(index)
	enemy_radius.remove_at(index)
	enemy_hit_cd.remove_at(index)

func _update_gems(delta: float) -> void:
	for i in range(gems.size() - 1, -1, -1):
		var pos := gems[i]
		var distance := pos.distance_to(player)

		if distance < 190.0:
			pos = pos.move_toward(player, 430.0 * delta)

		if pos.distance_to(player) < 28.0:
			gems.remove_at(i)
			xp += 1

			if xp >= xp_need:
				xp = 0
				level += 1
				xp_need = int(round(float(xp_need) * 1.25 + 2.0))
				hp = min(max_hp, hp + 12.0)

				if level == 4:
					blades.append(0.0)
				elif level == 7:
					blades.append(PI)

		else:
			gems[i] = pos

func _restart_run() -> void:
	hp = max_hp
	elapsed = 0.0
	spawn_clock = 0.0
	kills = 0
	level = 1
	xp = 0
	xp_need = 8
	enemy_pos.clear()
	enemy_hp.clear()
	enemy_max_hp.clear()
	enemy_speed.clear()
	enemy_radius.clear()
	enemy_hit_cd.clear()
	gems.clear()
	blades = [0.0, PI * 0.5, PI, PI * 1.5]
	player = Vector2(view_size.x * 0.5, view_size.y * 0.54)

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			if event.position.x < view_size.x * 0.55 and event.position.y > view_size.y * 0.62:
				joystick_active = true
				joystick_id = event.index
				joystick_center = event.position
				joystick_knob = event.position
		elif event.index == joystick_id:
			joystick_active = false
			joystick_id = -1
			_reset_joystick()

	elif event is InputEventScreenDrag:
		if event.index == joystick_id:
			joystick_knob = joystick_center + (event.position - joystick_center).limit_length(78.0)

func _reset_joystick() -> void:
	joystick_center = Vector2(105.0, view_size.y - bottom_h - 100.0)
	joystick_knob = joystick_center

func _draw() -> void:
	_draw_background()
	_draw_gems()
	_draw_enemies()
	_draw_player_and_blades()
	_draw_hud()
	_draw_joystick()

func _draw_background() -> void:
	draw_rect(Rect2(Vector2.ZERO, view_size), Color("#080D1D"))
	draw_rect(
		Rect2(0.0, _arena_top(), view_size.x, _arena_bottom() - _arena_top()),
		Color("#11172A")
	)

	var x := 0.0
	while x <= view_size.x:
		draw_line(
			Vector2(x, _arena_top()),
			Vector2(x, _arena_bottom()),
			Color(0.20, 0.28, 0.46, 0.18),
			1.0
		)
		x += 90.0

	var y := _arena_top()
	while y <= _arena_bottom():
		draw_line(
			Vector2(0.0, y),
			Vector2(view_size.x, y),
			Color(0.20, 0.28, 0.46, 0.18),
			1.0
		)
		y += 90.0

	draw_circle(player, 185.0, Color(0.35, 0.08, 0.58, 0.07))
	draw_arc(player, 185.0, 0.0, TAU, 80, Color(0.58, 0.18, 0.95, 0.22), 3.0)

func _draw_player_and_blades() -> void:
	draw_arc(player, 108.0, 0.0, TAU, 72, Color(0.70, 0.20, 1.0, 0.45), 4.0)

	for angle in blades:
		var blade_pos := player + Vector2(cos(angle), sin(angle)) * 108.0
		var tangent := Vector2(-sin(angle), cos(angle))
		draw_line(
			blade_pos - tangent * 20.0,
			blade_pos + tangent * 20.0,
			Color(0.80, 0.96, 1.0),
			8.0
		)
		draw_circle(blade_pos, 7.0, Color(0.20, 0.72, 1.0))

	draw_circle(player, 34.0, Color(0.36, 0.14, 1.0, 0.22))
	draw_circle(player, player_radius, Color(0.10, 0.82, 1.0))
	draw_circle(player, 14.0, Color("#10172A"))
	draw_line(
		player + Vector2(8.0, 6.0),
		player + Vector2(30.0, -15.0),
		Color(0.30, 0.95, 1.0),
		6.0
	)

func _draw_enemies() -> void:
	for i in range(enemy_pos.size()):
		var pos := enemy_pos[i]
		var radius := enemy_radius[i]

		for leg in range(6):
			var angle := TAU * float(leg) / 6.0
			var leg_start := pos + Vector2(cos(angle), sin(angle)) * (radius * 0.45)
			var leg_end := pos + Vector2(cos(angle), sin(angle)) * (radius + 10.0)
			draw_line(leg_start, leg_end, Color("#35394A"), 4.0)

		draw_circle(pos, radius, Color("#191A24"))
		draw_circle(pos, 8.0 if radius < 25.0 else 12.0, Color(1.0, 0.20, 0.18))

		var ratio := clamp(enemy_hp[i] / enemy_max_hp[i], 0.0, 1.0)
		draw_rect(Rect2(pos.x - 22.0, pos.y - radius - 13.0, 44.0, 5.0), Color("#381018"))
		draw_rect(Rect2(pos.x - 22.0, pos.y - radius - 13.0, 44.0 * ratio, 5.0), Color(1.0, 0.20, 0.28))

func _draw_gems() -> void:
	for pos in gems:
		draw_circle(pos, 10.0, Color(0.20, 1.0, 0.78))
		draw_circle(pos, 4.0, Color(0.82, 1.0, 1.0))

func _draw_hud() -> void:
	draw_rect(Rect2(0.0, 0.0, view_size.x, top_h), Color(0.02, 0.03, 0.07, 0.98))
	draw_rect(Rect2(0.0, view_size.y - bottom_h, view_size.x, bottom_h), Color(0.02, 0.03, 0.07, 0.98))

	_text("LV %d" % level, Vector2(22.0, 38.0), 24, Color(0.50, 0.90, 1.0))

	var xp_ratio := float(xp) / float(max(1, xp_need))
	draw_rect(Rect2(98.0, 22.0, 205.0, 15.0), Color("#212A40"))
	draw_rect(Rect2(98.0, 22.0, 205.0 * xp_ratio, 15.0), Color(0.15, 0.90, 1.0))

	var minutes := int(elapsed / 60.0)
	var seconds := int(elapsed) % 60
	_center_text("%02d:%02d" % [minutes, seconds], Vector2(view_size.x * 0.5, 40.0), 30, Color.WHITE)

	_text("KILL %d" % kills, Vector2(view_size.x - 145.0, 38.0), 20, Color.WHITE)

	draw_rect(Rect2(22.0, 72.0, 260.0, 13.0), Color("#351018"))
	draw_rect(Rect2(22.0, 72.0, 260.0 * clamp(hp / max_hp, 0.0, 1.0), 13.0), Color(0.18, 0.95, 0.45))

	_center_text("NEON SURVIVOR", Vector2(view_size.x * 0.5, view_size.y - 88.0), 20, Color(0.62, 0.82, 1.0))

func _draw_joystick() -> void:
	var center := joystick_center if joystick_active else Vector2(105.0, view_size.y - bottom_h - 100.0)
	var knob := joystick_knob if joystick_active else center

	draw_circle(center, 58.0, Color(0.90, 0.95, 1.0, 0.08))
	draw_arc(center, 58.0, 0.0, TAU, 64, Color(0.80, 0.90, 1.0, 0.32), 3.0)
	draw_circle(knob, 25.0, Color(0.80, 0.90, 1.0, 0.24))

func _text(value: String, pos: Vector2, size: int, color: Color) -> void:
	draw_string(ui_font, pos, value, HORIZONTAL_ALIGNMENT_LEFT, -1.0, size, color)

func _center_text(value: String, center: Vector2, size: int, color: Color) -> void:
	var width := ui_font.get_string_size(value, HORIZONTAL_ALIGNMENT_LEFT, -1.0, size).x
	_text(value, Vector2(center.x - width * 0.5, center.y), size, color)
