# Neon Survivor v0.1.9

Bu sürüm "APK açılıyor ancak yalnızca gri ekran görünüyor" sorununu düzeltmek için
oyun çizim kodunu sadeleştirir.

Önemli değişiklikler:
- Sorun çıkarabilecek `draw_polygon()` çağrıları tamamen kaldırıldı.
- Tüm temel grafikler `draw_rect`, `draw_circle`, `draw_line`, `draw_arc` ile çiziliyor.
- Ekran oranı `expand` yapıldı; uzun telefonlarda siyah bant azaltılır.
- Arena ve HUD gerçek viewport boyutuna göre çizilir.
- Gameplay korunur: joystick, düşman, dönen bıçak, XP, level, HP ve kill sayacı.

GitHub Actions workflow'unuz APK üretmeye başladıysa workflow'u DEĞİŞTİRMEYİN.
Sadece eski proje ZIP'ini bununla değiştirin.
