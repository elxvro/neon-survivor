extends Node

const W = 720.0
const ARENA_TOP = 120.0
const ARENA_BOTTOM = 1120.0

@onready var arena = $"../Arena"
@onready var player = $"../Arena/Player"
@onready var blades = [
	$"../Arena/Blade1",
	$"../Arena/Blade2",
	$"../Arena/Blade3",
	$"../Arena/Blade4"
]
@onready var level_label = $"../TopHud/Level"
@onready var timer_label = $"../TopHud/Timer"
@onready var kills_label = $"../TopHud/Kills"
@onready var hp_fill = $"../TopHud/HpFill"
@onready var xp_fill = $"../TopHud/XpFill"
@onready var joy_base = $"../JoyBase"
@onready var joy_knob = $"../JoyKnob"

var enemies = []
var gems = []

var elapsed = 0.0
var spawn_clock = 0.0
var kills = 0
var level = 1
var xp = 0
var xp_need = 8
var hp = 100.0

var touch_id = -1
var joystick_active = false
var joystick_center = Vector2(107.0, 1005.0)
var joystick_pos = Vector2(107.0, 1005.0)

func _ready():
	player.position = Vector2(338.0, 618.0)
	_update_hud()

func _process(delta):
	elapsed += delta
	spawn_clock += delta

	_move_player(delta)

	var spawn_delay = max(0.38, 0.95 - elapsed * 0.003)
	if spawn_clock >= spawn_delay:
		spawn_clock = 0.0
		_spawn_enemy()

	_update_blades()
	_update_enemies(delta)
	_update_gems(delta)
	_update_hud()

func _move_player(delta):
	var direction = Vector2.ZERO

	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		direction.x -= 1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		direction.x += 1.0
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		direction.y -= 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		direction.y += 1.0

	if joystick_active:
		direction = ((joystick_pos - joystick_center) / 70.0).limit_length(1.0)

	if direction.length() > 1.0:
		direction = direction.normalized()

	player.position += direction * 300.0 * delta
	player.position.x = clamp(player.position.x, 18.0, W - player.size.x - 18.0)
	player.position.y = clamp(player.position.y, ARENA_TOP + 18.0, ARENA_BOTTOM - player.size.y - 18.0)

func _player_center():
	return player.position + player.size * 0.5

func _update_blades():
	var center = _player_center()
	var radius = 105.0

	for i in range(blades.size()):
		var angle = elapsed * 2.7 + TAU * float(i) / float(blades.size())
		var p = center + Vector2(cos(angle), sin(angle)) * radius
		blades[i].position = p - blades[i].size * 0.5
		blades[i].rotation = angle

func _spawn_enemy():
	var enemy = ColorRect.new()
	var heavy = randf() > 0.82

	enemy.size = Vector2(46.0, 46.0) if heavy else Vector2(30.0, 30.0)
	enemy.color = Color(0.38, 0.08, 0.1, 1.0) if heavy else Color(0.17, 0.05, 0.08, 1.0)

	var side = randi() % 4
	if side == 0:
		enemy.position = Vector2(randf_range(20.0, 670.0), ARENA_TOP + 4.0)
	elif side == 1:
		enemy.position = Vector2(674.0, randf_range(150.0, 1050.0))
	elif side == 2:
		enemy.position = Vector2(randf_range(20.0, 670.0), 1070.0)
	else:
		enemy.position = Vector2(4.0, randf_range(150.0, 1050.0))

	arena.add_child(enemy)

	enemies.append({
		"node": enemy,
		"hp": 48.0 if heavy else 18.0,
		"speed": 54.0 if heavy else 86.0,
		"hit_cd": 0.0
	})

func _update_enemies(delta):
	var pc = _player_center()

	for i in range(enemies.size() - 1, -1, -1):
		var data = enemies[i]
		var enemy = data["node"]

		if not is_instance_valid(enemy):
			enemies.remove_at(i)
			continue

		var ec = enemy.position + enemy.size * 0.5
		var direction = pc - ec

		if direction.length() > 1.0:
			enemy.position += direction.normalized() * data["speed"] * delta

		data["hit_cd"] = max(0.0, data["hit_cd"] - delta)

		for blade in blades:
			var bc = blade.position + blade.size * 0.5
			if bc.distance_to(ec) < 34.0 and data["hit_cd"] <= 0.0:
				data["hp"] = data["hp"] - (10.0 + level)
				data["hit_cd"] = 0.18
				enemy.color = Color(1.0, 0.2, 0.28, 1.0)
				break

		ec = enemy.position + enemy.size * 0.5

		if ec.distance_to(pc) < 34.0:
			hp -= 20.0 * delta

		if data["hp"] <= 0.0:
			_spawn_gem(ec)
			enemy.queue_free()
			enemies.remove_at(i)
			kills += 1
		else:
			if data["hit_cd"] <= 0.02:
				enemy.color = Color(0.17, 0.05, 0.08, 1.0)
			enemies[i] = data

	if hp <= 0.0:
		_restart_run()

func _spawn_gem(center):
	var gem = ColorRect.new()
	gem.size = Vector2(16.0, 16.0)
	gem.position = center - Vector2(8.0, 8.0)
	gem.color = Color(0.15, 1.0, 0.72, 1.0)
	arena.add_child(gem)
	gems.append(gem)

func _update_gems(delta):
	var pc = _player_center()

	for i in range(gems.size() - 1, -1, -1):
		var gem = gems[i]

		if not is_instance_valid(gem):
			gems.remove_at(i)
			continue

		var gc = gem.position + gem.size * 0.5
		var distance = gc.distance_to(pc)

		if distance < 180.0:
			gem.position = gem.position.move_toward(pc - gem.size * 0.5, 380.0 * delta)

		if distance < 28.0:
			gem.queue_free()
			gems.remove_at(i)
			xp += 1

			if xp >= xp_need:
				xp = 0
				level += 1
				xp_need = int(xp_need * 1.25 + 2)
				hp = min(100.0, hp + 15.0)

func _restart_run():
	for data in enemies:
		if is_instance_valid(data["node"]):
			data["node"].queue_free()

	for gem in gems:
		if is_instance_valid(gem):
			gem.queue_free()

	enemies.clear()
	gems.clear()

	elapsed = 0.0
	spawn_clock = 0.0
	kills = 0
	level = 1
	xp = 0
	xp_need = 8
	hp = 100.0
	player.position = Vector2(338.0, 618.0)

func _update_hud():
	level_label.text = "LV %d" % level
	kills_label.text = "KILL %d" % kills

	var minutes = int(elapsed / 60.0)
	var seconds = int(elapsed) % 60
	timer_label.text = "%02d:%02d" % [minutes, seconds]

	hp_fill.size.x = 260.0 * clamp(hp / 100.0, 0.0, 1.0)
	xp_fill.size.x = 180.0 * clamp(float(xp) / float(max(1, xp_need)), 0.0, 1.0)

func _input(event):
	if event is InputEventScreenTouch:
		if event.pressed:
			if event.position.x < 300.0 and event.position.y > 820.0:
				touch_id = event.index
				joystick_active = true
				joystick_center = event.position
				joystick_pos = event.position
				joy_base.position = joystick_center - joy_base.size * 0.5
				joy_knob.position = joystick_center - joy_knob.size * 0.5
		elif event.index == touch_id:
			touch_id = -1
			joystick_active = false
			joystick_center = Vector2(107.0, 1005.0)
			joystick_pos = joystick_center
			joy_base.position = Vector2(42.0, 940.0)
			joy_knob.position = Vector2(80.0, 978.0)

	elif event is InputEventScreenDrag:
		if event.index == touch_id:
			joystick_pos = joystick_center + (event.position - joystick_center).limit_length(70.0)
			joy_knob.position = joystick_pos - joy_knob.size * 0.5
