# Neon Survivor v0.2.0 — Boot-safe rebuild

Bu paket siyah ekran sorununu izole etmek için oyunu farklı şekilde kurar.

## Neden farklı?
Ana sahne artık script olmadan da görünür:
- koyu mavi arena
- üst HUD
- "NEON SURVIVOR • ARENA ONLINE" yazısı
- oyuncu karesi
- dört silah
- alt yetenek kutuları
- joystick

Oyun mantığı ayrı `GameLogic` node'una bağlıdır. Böylece script tarafında bir hata olsa bile
tamamen siyah ekran yerine statik oyun arayüzü görünmelidir.

## Workflow
APK derleme akışınız artık başarılı olduğu için workflow dosyasını değiştirmeyin.
Sadece repo içindeki eski Neon Survivor ZIP'ini bu dosyayla değiştirin.
