extends Node2D

const VIEW_SIZE := Vector2(720.0, 1280.0)
const ARENA_TOP := 120.0
const ARENA_BOTTOM := 1120.0

var player_pos := Vector2(360.0, 690.0)
var player_radius := 23.0
var player_speed := 300.0
var hp := 100.0
var max_hp := 100.0
var invulnerable_time := 0.0

var elapsed := 0.0
var spawn_timer := 0.0
var kills := 0
var coins := 0
var level := 1
var xp := 0
var xp_needed := 8

var enemies: Array[Dictionary] = []
var gems: Array[Dictionary] = []
var damage_numbers: Array[Dictionary] = []
var fx_particles: Array[Dictionary] = []
var blades: Array[Dictionary] = []

var touch_id := -1
var joystick_active := false
var joystick_center := Vector2(105.0, 1015.0)
var joystick_knob := Vector2(105.0, 1015.0)

var is_paused := false
var game_over := false

var ui_font: Font

func _ready() -> void:
	ui_font = ThemeDB.fallback_font
	for i in range(4):
		blades.append({"angle": TAU * float(i) / 4.0})
	queue_redraw()

func _process(delta: float) -> void:
	if is_paused or game_over:
		queue_redraw()
		return

	elapsed += delta
	invulnerable_time = max(0.0, invulnerable_time - delta)

	_update_player(delta)
	_update_spawning(delta)
	_update_blades(delta)
	_update_enemies(delta)
	_update_gems(delta)
	_update_effects(delta)
	queue_redraw()

func _update_player(delta: float) -> void:
	var direction := Vector2.ZERO

	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		direction.x -= 1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		direction.x += 1.0
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		direction.y -= 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		direction.y += 1.0

	if joystick_active:
		var touch_vector := (joystick_knob - joystick_center) / 75.0
		if touch_vector.length() > 0.12:
			direction = touch_vector.limit_length(1.0)

	if direction.length() > 1.0:
		direction = direction.normalized()

	player_pos += direction * player_speed * delta
	player_pos.x = clamp(player_pos.x, 34.0, VIEW_SIZE.x - 34.0)
	player_pos.y = clamp(player_pos.y, ARENA_TOP + 34.0, ARENA_BOTTOM - 34.0)

func _update_spawning(delta: float) -> void:
	spawn_timer += delta
	var spawn_delay := max(0.28, 0.92 - elapsed * 0.004)

	while spawn_timer >= spawn_delay:
		spawn_timer -= spawn_delay
		_spawn_enemy()

func _spawn_enemy() -> void:
	var side := randi() % 4
	var pos := Vector2.ZERO

	match side:
		0:
			pos = Vector2(randf_range(0.0, VIEW_SIZE.x), ARENA_TOP - 35.0)
		1:
			pos = Vector2(VIEW_SIZE.x + 35.0, randf_range(ARENA_TOP, ARENA_BOTTOM))
		2:
			pos = Vector2(randf_range(0.0, VIEW_SIZE.x), ARENA_BOTTOM + 35.0)
		_:
			pos = Vector2(-35.0, randf_range(ARENA_TOP, ARENA_BOTTOM))

	var kind := 0
	var radius := 18.0
	var enemy_hp := 18.0 + elapsed * 0.08
	var speed := 80.0 + elapsed * 0.07
	var roll := randf()

	if roll > 0.83:
		kind = 1
		radius = 30.0
		enemy_hp *= 3.4
		speed *= 0.60
	elif roll > 0.60:
		kind = 2
		radius = 15.0
		enemy_hp *= 0.72
		speed *= 1.35

	enemies.append({
		"pos": pos,
		"hp": enemy_hp,
		"max_hp": enemy_hp,
		"speed": speed,
		"radius": radius,
		"kind": kind,
		"hit_cooldown": 0.0,
		"flash": 0.0
	})

func _update_enemies(delta: float) -> void:
	for i in range(enemies.size() - 1, -1, -1):
		var enemy := enemies[i]
		var to_player: Vector2 = player_pos - enemy["pos"]

		if to_player.length() > 0.1:
			enemy["pos"] += to_player.normalized() * float(enemy["speed"]) * delta

		enemy["hit_cooldown"] = max(0.0, float(enemy["hit_cooldown"]) - delta)
		enemy["flash"] = max(0.0, float(enemy["flash"]) - delta)

		if enemy["pos"].distance_to(player_pos) < float(enemy["radius"]) + player_radius:
			if invulnerable_time <= 0.0:
				var contact_damage := 20.0 if int(enemy["kind"]) == 1 else 12.0
				hp -= contact_damage
				invulnerable_time = 0.55
				_spawn_burst(player_pos, 12, Color(1.0, 0.22, 0.30))

				if hp <= 0.0:
					hp = 0.0
					game_over = true

			var push_direction := (enemy["pos"] - player_pos).normalized()
			enemy["pos"] += push_direction * 18.0

		enemies[i] = enemy

func _update_blades(delta: float) -> void:
	var orbit_radius := 112.0

	for blade in blades:
		blade["angle"] = float(blade["angle"]) + delta * 2.8

	for enemy_index in range(enemies.size() - 1, -1, -1):
		var enemy := enemies[enemy_index]

		for blade in blades:
			var angle := float(blade["angle"])
			var blade_pos := player_pos + Vector2(cos(angle), sin(angle)) * orbit_radius

			if blade_pos.distance_to(enemy["pos"]) < float(enemy["radius"]) + 18.0:
				if float(enemy["hit_cooldown"]) <= 0.0:
					var damage := 9.0 + float(level) * 1.25
					enemy["hp"] = float(enemy["hp"]) - damage
					enemy["hit_cooldown"] = 0.18
					enemy["flash"] = 0.08
					damage_numbers.append({
						"pos": enemy["pos"],
						"value": int(round(damage)),
						"life": 0.62
					})
					_spawn_burst(enemy["pos"], 5, Color(0.35, 0.82, 1.0))
				break

		if float(enemy["hp"]) <= 0.0:
			_enemy_died(enemy)
			enemies.remove_at(enemy_index)
		else:
			enemies[enemy_index] = enemy

func _enemy_died(enemy: Dictionary) -> void:
	kills += 1

	if randi() % 4 == 0:
		coins += 1

	var gem_value := 3 if int(enemy["kind"]) == 1 else 1
	gems.append({
		"pos": enemy["pos"],
		"value": gem_value,
		"phase": randf() * TAU
	})

	_spawn_burst(
		enemy["pos"],
		14 if int(enemy["kind"]) == 1 else 8,
		Color(1.0, 0.25, 0.12)
	)

func _update_gems(delta: float) -> void:
	for i in range(gems.size() - 1, -1, -1):
		var gem := gems[i]
		gem["phase"] = float(gem["phase"]) + delta * 3.0
		var distance := gem["pos"].distance_to(player_pos)

		if distance < 180.0:
			var pull_speed := lerp(120.0, 460.0, 1.0 - distance / 180.0)
			gem["pos"] = gem["pos"].move_toward(player_pos, pull_speed * delta)

		if gem["pos"].distance_to(player_pos) < 28.0:
			xp += int(gem["value"])
			gems.remove_at(i)
			_check_level_up()
		else:
			gems[i] = gem

func _check_level_up() -> void:
	while xp >= xp_needed:
		xp -= xp_needed
		level += 1
		xp_needed = int(round(float(xp_needed) * 1.28 + 2.0))
		max_hp += 4.0
		hp = min(max_hp, hp + 12.0)
		player_speed += 3.0

		if level == 4 and blades.size() < 5:
			blades.append({"angle": 0.0})
		elif level == 7 and blades.size() < 6:
			blades.append({"angle": PI})

		_spawn_burst(player_pos, 28, Color(0.30, 1.0, 0.82))

func _spawn_burst(position: Vector2, count: int, color: Color) -> void:
	for _i in range(count):
		var angle := randf() * TAU
		var speed := randf_range(55.0, 190.0)
		fx_particles.append({
			"pos": position,
			"velocity": Vector2(cos(angle), sin(angle)) * speed,
			"life": randf_range(0.20, 0.55),
			"color": color
		})

func _update_effects(delta: float) -> void:
	for i in range(damage_numbers.size() - 1, -1, -1):
		var item := damage_numbers[i]
		item["life"] = float(item["life"]) - delta
		item["pos"].y -= 52.0 * delta

		if float(item["life"]) <= 0.0:
			damage_numbers.remove_at(i)
		else:
			damage_numbers[i] = item

	for i in range(fx_particles.size() - 1, -1, -1):
		var particle := fx_particles[i]
		particle["life"] = float(particle["life"]) - delta
		particle["pos"] += particle["velocity"] * delta
		particle["velocity"] *= 0.92

		if float(particle["life"]) <= 0.0:
			fx_particles.remove_at(i)
		else:
			fx_particles[i] = particle

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			if game_over:
				_restart()
				return

			if event.position.y <= 105.0 and event.position.x >= 615.0:
				is_paused = not is_paused
				return

			if event.position.y >= 900.0 and event.position.x <= 360.0:
				touch_id = event.index
				joystick_active = true
				joystick_center = event.position
				joystick_knob = event.position
		elif event.index == touch_id:
			touch_id = -1
			joystick_active = false
			joystick_center = Vector2(105.0, 1015.0)
			joystick_knob = joystick_center

	elif event is InputEventScreenDrag:
		if event.index == touch_id:
			joystick_knob = joystick_center + (event.position - joystick_center).limit_length(75.0)

	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		if game_over:
			_restart()
		elif event.position.y <= 105.0 and event.position.x >= 615.0:
			is_paused = not is_paused

	elif event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		is_paused = not is_paused

func _restart() -> void:
	player_pos = Vector2(360.0, 690.0)
	player_speed = 300.0
	hp = 100.0
	max_hp = 100.0
	invulnerable_time = 0.0

	elapsed = 0.0
	spawn_timer = 0.0
	kills = 0
	coins = 0
	level = 1
	xp = 0
	xp_needed = 8

	enemies.clear()
	gems.clear()
	damage_numbers.clear()
	fx_particles.clear()
	blades.clear()

	for i in range(4):
		blades.append({"angle": TAU * float(i) / 4.0})

	is_paused = false
	game_over = false

func _draw() -> void:
	_draw_background()
	_draw_gems()
	_draw_enemies()
	_draw_blades()
	_draw_player()
	_draw_effects()
	_draw_hud()
	_draw_joystick()

	if is_paused:
		draw_rect(Rect2(Vector2.ZERO, VIEW_SIZE), Color(0.0, 0.0, 0.0, 0.62))
		_center_text("DURAKLATILDI", Vector2(360.0, 600.0), 38, Color.WHITE)

	if game_over:
		draw_rect(Rect2(Vector2.ZERO, VIEW_SIZE), Color(0.0, 0.0, 0.0, 0.72))
		_center_text("OYUN BITTI", Vector2(360.0, 510.0), 46, Color.WHITE)
		_center_text("Skor: %d" % kills, Vector2(360.0, 575.0), 30, Color(0.55, 0.88, 1.0))
		_center_text("Tekrar baslamak icin dokun", Vector2(360.0, 640.0), 22, Color(0.85, 0.88, 0.95))

func _draw_background() -> void:
	draw_rect(Rect2(Vector2.ZERO, VIEW_SIZE), Color("#080D1D"))
	draw_rect(
		Rect2(0.0, ARENA_TOP, VIEW_SIZE.x, ARENA_BOTTOM - ARENA_TOP),
		Color("#12182C")
	)

	for x in range(0, 721, 90):
		draw_line(
			Vector2(float(x), ARENA_TOP),
			Vector2(float(x), ARENA_BOTTOM),
			Color(0.18, 0.25, 0.38, 0.28),
			1.0
		)

	for y in range(int(ARENA_TOP), int(ARENA_BOTTOM) + 1, 90):
		draw_line(
			Vector2(0.0, float(y)),
			Vector2(VIEW_SIZE.x, float(y)),
			Color(0.18, 0.25, 0.38, 0.28),
			1.0
		)

	draw_circle(Vector2(360.0, 650.0), 185.0, Color(0.35, 0.08, 0.58, 0.10))
	draw_arc(
		Vector2(360.0, 650.0),
		185.0,
		0.0,
		TAU,
		96,
		Color(0.58, 0.18, 0.95, 0.28),
		3.0
	)

func _draw_player() -> void:
	if invulnerable_time > 0.0 and int(invulnerable_time * 20.0) % 2 == 0:
		return

	draw_circle(player_pos, player_radius + 12.0, Color(0.30, 0.18, 1.0, 0.16))
	draw_circle(player_pos, player_radius, Color(0.10, 0.82, 1.0))
	draw_circle(player_pos, player_radius - 7.0, Color("#11182A"))

	var body := PackedVector2Array([
		player_pos + Vector2(0.0, -19.0),
		player_pos + Vector2(11.0, -6.0),
		player_pos + Vector2(7.0, 12.0),
		player_pos + Vector2(-7.0, 12.0),
		player_pos + Vector2(-11.0, -6.0)
	])
	draw_polygon(body, PackedColorArray([Color(0.88, 0.96, 1.0)]))
	draw_line(
		player_pos + Vector2(10.0, 4.0),
		player_pos + Vector2(31.0, -13.0),
		Color(0.20, 0.92, 1.0),
		6.0
	)

func _draw_blades() -> void:
	var orbit_radius := 112.0
	draw_arc(
		player_pos,
		orbit_radius,
		0.0,
		TAU,
		96,
		Color(0.68, 0.22, 1.0, 0.38),
		4.0
	)

	for blade in blades:
		var angle := float(blade["angle"])
		var blade_pos := player_pos + Vector2(cos(angle), sin(angle)) * orbit_radius
		var tangent := Vector2(-sin(angle), cos(angle))
		var normal := tangent.orthogonal()

		var shape := PackedVector2Array([
			blade_pos + tangent * 23.0,
			blade_pos - tangent * 15.0 + normal * 8.0,
			blade_pos - tangent * 9.0,
			blade_pos - tangent * 15.0 - normal * 8.0
		])
		draw_polygon(shape, PackedColorArray([Color(0.30, 0.86, 1.0)]))

		var outline := PackedVector2Array([
			shape[0], shape[1], shape[2], shape[3], shape[0]
		])
		draw_polyline(outline, Color.WHITE, 2.0)

func _draw_enemies() -> void:
	for enemy in enemies:
		var enemy_pos: Vector2 = enemy["pos"]
		var radius := float(enemy["radius"])
		var flash_color := Color.WHITE if float(enemy["flash"]) > 0.0 else Color(1.0, 0.22, 0.20)

		if int(enemy["kind"]) == 0:
			draw_circle(enemy_pos, radius, Color("#181925"))
			for leg in range(6):
				var a := TAU * float(leg) / 6.0
				draw_line(
					enemy_pos + Vector2(cos(a), sin(a)) * 9.0,
					enemy_pos + Vector2(cos(a), sin(a)) * 29.0,
					Color("#34394B"),
					5.0
				)
			draw_circle(enemy_pos, 7.0, flash_color)

		elif int(enemy["kind"]) == 1:
			draw_circle(enemy_pos, radius, Color("#25202A"))
			draw_circle(enemy_pos, radius - 8.0, Color("#423034"))
			draw_circle(enemy_pos, 10.0, Color(1.0, 0.30, 0.10))

		else:
			var triangle := PackedVector2Array([
				enemy_pos + Vector2(0.0, -radius),
				enemy_pos + Vector2(radius, radius),
				enemy_pos + Vector2(-radius, radius)
			])
			draw_polygon(triangle, PackedColorArray([Color("#201C2D")]))
			var triangle_outline := PackedVector2Array([
				triangle[0], triangle[1], triangle[2], triangle[0]
			])
			draw_polyline(triangle_outline, flash_color, 3.0)

		var hp_ratio := clamp(float(enemy["hp"]) / float(enemy["max_hp"]), 0.0, 1.0)
		draw_rect(
			Rect2(enemy_pos.x - 22.0, enemy_pos.y - radius - 14.0, 44.0, 5.0),
			Color("#351018")
		)
		draw_rect(
			Rect2(enemy_pos.x - 22.0, enemy_pos.y - radius - 14.0, 44.0 * hp_ratio, 5.0),
			Color(1.0, 0.18, 0.26)
		)

func _draw_gems() -> void:
	for gem in gems:
		var gem_pos: Vector2 = gem["pos"]
		var size := 10.0 + sin(float(gem["phase"])) * 1.5
		var diamond := PackedVector2Array([
			gem_pos + Vector2(0.0, -size),
			gem_pos + Vector2(size * 0.72, 0.0),
			gem_pos + Vector2(0.0, size),
			gem_pos + Vector2(-size * 0.72, 0.0)
		])
		draw_polygon(diamond, PackedColorArray([Color(0.20, 1.0, 0.78)]))
		var outline := PackedVector2Array([
			diamond[0], diamond[1], diamond[2], diamond[3], diamond[0]
		])
		draw_polyline(outline, Color(0.78, 1.0, 1.0), 2.0)

func _draw_effects() -> void:
	for item in damage_numbers:
		var alpha := clamp(float(item["life"]) / 0.62, 0.0, 1.0)
		_text(
			str(item["value"]),
			item["pos"],
			19,
			Color(1.0, 0.45, 0.72, alpha)
		)

	for particle in fx_particles:
		var alpha := clamp(float(particle["life"]) / 0.55, 0.0, 1.0)
		var color: Color = particle["color"]
		color.a = alpha
		draw_circle(particle["pos"], 3.2, color)

func _draw_hud() -> void:
	draw_rect(Rect2(0.0, 0.0, 720.0, 120.0), Color(0.02, 0.03, 0.07, 0.97))
	draw_rect(Rect2(0.0, 1120.0, 720.0, 160.0), Color(0.02, 0.03, 0.07, 0.97))

	_text("LV %d" % level, Vector2(22.0, 42.0), 25, Color(0.55, 0.90, 1.0))

	var xp_ratio := float(xp) / float(max(1, xp_needed))
	draw_rect(Rect2(108.0, 24.0, 218.0, 16.0), Color("#20283B"))
	draw_rect(Rect2(108.0, 24.0, 218.0 * xp_ratio, 16.0), Color(0.18, 0.90, 1.0))

	var minutes := int(elapsed / 60.0)
	var seconds := int(elapsed) % 60
	_center_text("%02d:%02d" % [minutes, seconds], Vector2(365.0, 46.0), 31, Color.WHITE)

	_text("KILL %d" % kills, Vector2(500.0, 39.0), 19, Color.WHITE)
	_text("COIN %d" % coins, Vector2(500.0, 70.0), 18, Color(1.0, 0.82, 0.20))

	draw_rect(Rect2(650.0, 18.0, 48.0, 48.0), Color("#151D30"))
	_center_text("II", Vector2(674.0, 53.0), 24, Color.WHITE)

	draw_rect(Rect2(22.0, 82.0, 260.0, 13.0), Color("#331019"))
	var hp_ratio := clamp(hp / max_hp, 0.0, 1.0)
	draw_rect(Rect2(22.0, 82.0, 260.0 * hp_ratio, 13.0), Color(0.20, 0.95, 0.45))
	_text("%d/%d" % [int(hp), int(max_hp)], Vector2(295.0, 95.0), 17, Color(0.87, 0.96, 0.90))

	var labels := ["BLD", "RKT", "DRN", "MED"]
	for i in range(4):
		var card := Rect2(155.0 + float(i) * 105.0, 1152.0, 80.0, 80.0)
		draw_rect(card, Color("#101728"))
		draw_rect(card, Color(0.25, 0.55 + float(i) * 0.08, 0.95, 0.90), false, 3.0)
		_center_text(labels[i], card.position + Vector2(40.0, 49.0), 16, Color.WHITE)

func _draw_joystick() -> void:
	var center := joystick_center if joystick_active else Vector2(105.0, 1015.0)
	var knob := joystick_knob if joystick_active else center

	draw_circle(center, 58.0, Color(0.9, 0.95, 1.0, 0.09))
	draw_arc(center, 58.0, 0.0, TAU, 64, Color(0.8, 0.9, 1.0, 0.28), 3.0)
	draw_circle(knob, 25.0, Color(0.8, 0.9, 1.0, 0.22))

func _text(text: String, position: Vector2, font_size: int, color: Color) -> void:
	draw_string(
		ui_font,
		position,
		text,
		HORIZONTAL_ALIGNMENT_LEFT,
		-1.0,
		font_size,
		color
	)

func _center_text(text: String, center: Vector2, font_size: int, color: Color) -> void:
	var text_width := ui_font.get_string_size(
		text,
		HORIZONTAL_ALIGNMENT_LEFT,
		-1.0,
		font_size
	).x

	_text(
		text,
		Vector2(center.x - text_width * 0.5, center.y),
		font_size,
		color
	)
