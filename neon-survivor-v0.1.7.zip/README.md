# Neon Survivor v0.1.7

Bu sürüm Android export için ETC2/ASTC mobil texture import ayarını etkinleştirir,
eski .godot import cache'ini temizler ve GitHub Actions'ta Godot CI'nin kendi
Android/JDK/keystore ayarlarını kullanır.

Workflow:
.github/workflows/android-build.yml

GitHub Actions artifact:
neon-survivor-v0.1.7-apk
