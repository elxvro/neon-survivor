extends Node

const TOP_H := 108.0
const BOTTOM_H := 150.0

@onready var root: Control = $".."
@onready var world: Control = $"../World"
@onready var level_label: Label = $"../TopHud/Level"
@onready var timer_label: Label = $"../TopHud/Timer"
@onready var kills_label: Label = $"../TopHud/Kills"
@onready var hp_fill: ColorRect = $"../TopHud/HpFill"
@onready var xp_fill: ColorRect = $"../TopHud/XpFill"
@onready var boss_back: ColorRect = $"../TopHud/BossBarBack"
@onready var boss_bar: ColorRect = $"../TopHud/BossBar"
@onready var joy_base: ColorRect = $"../JoyBase"
@onready var joy_knob: ColorRect = $"../JoyKnob"

var tex_player = preload("res://assets/player.svg")
var tex_spider = preload("res://assets/spider.svg")
var tex_drone = preload("res://assets/drone.svg")
var tex_brute = preload("res://assets/brute.svg")
var tex_blade = preload("res://assets/blade.svg")
var tex_gem = preload("res://assets/gem.svg")
var tex_boss = preload("res://assets/boss.svg")

var player: TextureRect
var player_glow: ColorRect
var blade_nodes: Array = []
var enemies: Array = []
var gems: Array = []

var elapsed := 0.0
var spawn_clock := 0.0
var kills := 0
var level := 1
var xp := 0
var xp_need := 8
var hp := 100.0
var max_hp := 100.0

var blade_damage := 11.0
var player_speed := 310.0
var magnet_radius := 190.0
var crit_chance := 0.10
var choosing_upgrade := false
var boss_spawned := false

var touch_id := -1
var joystick_active := false
var joystick_center := Vector2.ZERO
var joystick_pos := Vector2.ZERO

func _ready() -> void:
	_create_player()
	_set_default_joystick()
	_update_hud()

func _process(delta: float) -> void:
	if choosing_upgrade:
		return

	elapsed += delta
	spawn_clock += delta

	_move_player(delta)
	_update_blades()

	var spawn_delay := max(0.26, 0.90 - elapsed * 0.0045)
	while spawn_clock >= spawn_delay:
		spawn_clock -= spawn_delay
		_spawn_enemy(false)

	if elapsed >= 45.0 and not boss_spawned:
		boss_spawned = true
		_spawn_enemy(true)

	_update_enemies(delta)
	_update_gems(delta)
	_update_hud()

func _world_size() -> Vector2:
	return world.size

func _create_texture_node(texture: Texture2D, size: Vector2) -> TextureRect:
	var node := TextureRect.new()
	node.texture = texture
	node.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	node.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	node.size = size
	node.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return node

func _create_player() -> void:
	player_glow = ColorRect.new()
	player_glow.color = Color(0.35, 0.12, 1.0, 0.18)
	player_glow.size = Vector2(86, 86)
	world.add_child(player_glow)

	player = _create_texture_node(tex_player, Vector2(58, 58))
	world.add_child(player)

	var ws := _world_size()
	player.position = Vector2(ws.x * 0.5 - 29.0, ws.y * 0.54 - 29.0)

	for i in range(4):
		_add_blade(TAU * float(i) / 4.0)

func _add_blade(angle: float) -> void:
	var node := _create_texture_node(tex_blade, Vector2(42, 42))
	world.add_child(node)
	blade_nodes.append({"node": node, "angle": angle})

func _player_center() -> Vector2:
	return player.position + player.size * 0.5

func _move_player(delta: float) -> void:
	var direction := Vector2.ZERO

	if joystick_active:
		direction = ((joystick_pos - joystick_center) / 76.0).limit_length(1.0)

	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		direction.x -= 1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		direction.x += 1.0
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		direction.y -= 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		direction.y += 1.0

	if direction.length() > 1.0:
		direction = direction.normalized()

	player.position += direction * player_speed * delta
	player.position.x = clamp(player.position.x, 8.0, _world_size().x - player.size.x - 8.0)
	player.position.y = clamp(player.position.y, 8.0, _world_size().y - player.size.y - 8.0)

	player_glow.position = _player_center() - player_glow.size * 0.5

func _update_blades() -> void:
	var center := _player_center()
	var orbit := 104.0

	for data in blade_nodes:
		data["angle"] = float(data["angle"]) + 0.045
		var a := float(data["angle"])
		var node: TextureRect = data["node"]
		var p := center + Vector2(cos(a), sin(a)) * orbit
		node.position = p - node.size * 0.5
		node.rotation = a + PI * 0.5

func _spawn_enemy(as_boss: bool) -> void:
	var kind := 0
	var texture := tex_spider
	var size := Vector2(48, 48)
	var enemy_hp := 24.0 + elapsed * 0.09
	var speed := 88.0
	var damage := 16.0

	if as_boss:
		kind = 3
		texture = tex_boss
		size = Vector2(116, 116)
		enemy_hp = 520.0
		speed = 42.0
		damage = 35.0
	else:
		var roll := randf()
		if roll > 0.84:
			kind = 2
			texture = tex_brute
			size = Vector2(72, 72)
			enemy_hp *= 3.2
			speed = 54.0
			damage = 26.0
		elif roll > 0.58:
			kind = 1
			texture = tex_drone
			size = Vector2(44, 44)
			enemy_hp *= 0.75
			speed = 125.0
			damage = 12.0

	var node := _create_texture_node(texture, size)
	world.add_child(node)

	var ws := _world_size()
	var side := randi() % 4

	if side == 0:
		node.position = Vector2(randf_range(0.0, max(1.0, ws.x - size.x)), -size.y)
	elif side == 1:
		node.position = Vector2(ws.x, randf_range(0.0, max(1.0, ws.y - size.y)))
	elif side == 2:
		node.position = Vector2(randf_range(0.0, max(1.0, ws.x - size.x)), ws.y)
	else:
		node.position = Vector2(-size.x, randf_range(0.0, max(1.0, ws.y - size.y)))

	var hp_back := ColorRect.new()
	hp_back.color = Color(0.20, 0.02, 0.06, 0.95)
	hp_back.size = Vector2(size.x, 5)
	hp_back.position = Vector2(0, -8)
	node.add_child(hp_back)

	var hp_bar := ColorRect.new()
	hp_bar.color = Color(1.0, 0.16, 0.26, 1.0)
	hp_bar.size = Vector2(size.x, 5)
	hp_back.add_child(hp_bar)

	enemies.append({
		"node": node,
		"hp": enemy_hp,
		"max_hp": enemy_hp,
		"speed": speed,
		"damage": damage,
		"hit_cd": 0.0,
		"hp_bar": hp_bar,
		"kind": kind,
		"boss": as_boss
	})

	if as_boss:
		boss_back.visible = true

func _update_enemies(delta: float) -> void:
	var pc := _player_center()

	for i in range(enemies.size() - 1, -1, -1):
		var data = enemies[i]
		var node: TextureRect = data["node"]

		if not is_instance_valid(node):
			enemies.remove_at(i)
			continue

		var ec := node.position + node.size * 0.5
		var to_player := pc - ec

		if to_player.length() > 2.0:
			node.position += to_player.normalized() * float(data["speed"]) * delta

		data["hit_cd"] = max(0.0, float(data["hit_cd"]) - delta)

		for blade_data in blade_nodes:
			var blade: TextureRect = blade_data["node"]
			var bc := blade.position + blade.size * 0.5

			if bc.distance_to(ec) < node.size.x * 0.34 + 17.0 and float(data["hit_cd"]) <= 0.0:
				var crit := randf() < crit_chance
				var dmg := blade_damage * (2.0 if crit else 1.0)
				data["hp"] = float(data["hp"]) - dmg
				data["hit_cd"] = 0.16
				_show_damage(ec, int(round(dmg)), crit)
				_burst(ec, Color(0.30, 0.80, 1.0, 1.0), 5)
				break

		ec = node.position + node.size * 0.5

		if ec.distance_to(pc) < node.size.x * 0.32 + 25.0:
			hp -= float(data["damage"]) * delta

		var ratio := clamp(float(data["hp"]) / float(data["max_hp"]), 0.0, 1.0)
		data["hp_bar"].size.x = node.size.x * ratio

		if bool(data["boss"]):
			boss_bar.size.x = 260.0 * ratio

		if float(data["hp"]) <= 0.0:
			var was_boss := bool(data["boss"])
			_spawn_gem(ec, 8 if was_boss else (3 if int(data["kind"]) == 2 else 1))
			_burst(ec, Color(1.0, 0.20, 0.16, 1.0), 16 if was_boss else 9)
			node.queue_free()
			enemies.remove_at(i)
			kills += 12 if was_boss else 1

			if was_boss:
				boss_back.visible = false
		else:
			enemies[i] = data

	if hp <= 0.0:
		_restart_run()

func _spawn_gem(center: Vector2, value: int) -> void:
	var node := _create_texture_node(tex_gem, Vector2(26, 32))
	node.position = center - node.size * 0.5
	world.add_child(node)
	gems.append({"node": node, "value": value})

func _update_gems(delta: float) -> void:
	var pc := _player_center()

	for i in range(gems.size() - 1, -1, -1):
		var data = gems[i]
		var node: TextureRect = data["node"]

		if not is_instance_valid(node):
			gems.remove_at(i)
			continue

		var gc := node.position + node.size * 0.5
		var distance := gc.distance_to(pc)

		if distance < magnet_radius:
			node.position = node.position.move_toward(pc - node.size * 0.5, 430.0 * delta)

		if distance < 28.0:
			xp += int(data["value"])
			node.queue_free()
			gems.remove_at(i)
			_check_level_up()

func _check_level_up() -> void:
	if xp < xp_need:
		return

	xp -= xp_need
	level += 1
	xp_need = int(round(float(xp_need) * 1.28 + 2.0))
	_show_upgrade_cards()

func _show_upgrade_cards() -> void:
	choosing_upgrade = true

	var overlay := ColorRect.new()
	overlay.name = "UpgradeOverlay"
	overlay.color = Color(0.005, 0.008, 0.025, 0.92)
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(overlay)

	var title := Label.new()
	title.text = "LEVEL UP"
	title.position = Vector2(0, 170)
	title.size = Vector2(root.size.x, 60)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 34)
	title.add_theme_color_override("font_color", Color(0.55, 0.92, 1.0))
	overlay.add_child(title)

	var choices := [
		["ENERGY BLADES", "+25% blade damage", 0],
		["PHASE STEP", "+12% move speed", 1],
		["MAGNET CORE", "+40 pickup range", 2],
		["NANO REPAIR", "+20 max HP + heal", 3],
		["EXTRA BLADE", "+1 orbiting blade", 4],
		["CRITICAL CORE", "+8% crit chance", 5]
	]
	choices.shuffle()

	for i in range(3):
		var choice = choices[i]
		var button := Button.new()
		button.position = Vector2(70, 285 + i * 180)
		button.size = Vector2(root.size.x - 140, 140)
		button.text = "%s\n%s" % [choice[0], choice[1]]
		button.add_theme_font_size_override("font_size", 22)
		button.pressed.connect(_choose_upgrade.bind(int(choice[2]), overlay))
		overlay.add_child(button)

func _choose_upgrade(kind: int, overlay: ColorRect) -> void:
	match kind:
		0:
			blade_damage *= 1.25
		1:
			player_speed *= 1.12
		2:
			magnet_radius += 40.0
		3:
			max_hp += 20.0
			hp = min(max_hp, hp + 35.0)
		4:
			if blade_nodes.size() < 8:
				_add_blade(randf() * TAU)
		5:
			crit_chance = min(0.55, crit_chance + 0.08)

	overlay.queue_free()
	choosing_upgrade = false
	_burst(_player_center(), Color(0.25, 1.0, 0.78, 1.0), 18)

func _show_damage(pos: Vector2, amount: int, crit: bool) -> void:
	var label := Label.new()
	label.text = str(amount)
	label.position = pos - Vector2(28, 20)
	label.size = Vector2(56, 30)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", 22 if not crit else 27)
	label.add_theme_color_override("font_color", Color(1.0, 0.42, 0.72) if not crit else Color(1.0, 0.82, 0.22))
	world.add_child(label)

	var tween := create_tween()
	tween.set_parallel(true)
	tween.tween_property(label, "position", label.position - Vector2(0, 42), 0.55)
	tween.tween_property(label, "modulate:a", 0.0, 0.55)
	tween.set_parallel(false)
	tween.tween_callback(label.queue_free)

func _burst(pos: Vector2, color: Color, count: int) -> void:
	for n in range(count):
		var p := ColorRect.new()
		p.color = color
		p.size = Vector2(5, 5)
		p.position = pos
		world.add_child(p)

		var angle := randf() * TAU
		var dist := randf_range(25.0, 70.0)
		var target := pos + Vector2(cos(angle), sin(angle)) * dist

		var tween := create_tween()
		tween.set_parallel(true)
		tween.tween_property(p, "position", target, 0.32)
		tween.tween_property(p, "modulate:a", 0.0, 0.32)
		tween.set_parallel(false)
		tween.tween_callback(p.queue_free)

func _restart_run() -> void:
	for data in enemies:
		if is_instance_valid(data["node"]):
			data["node"].queue_free()
	for data in gems:
		if is_instance_valid(data["node"]):
			data["node"].queue_free()
	for data in blade_nodes:
		if is_instance_valid(data["node"]):
			data["node"].queue_free()

	enemies.clear()
	gems.clear()
	blade_nodes.clear()

	elapsed = 0.0
	spawn_clock = 0.0
	kills = 0
	level = 1
	xp = 0
	xp_need = 8
	max_hp = 100.0
	hp = 100.0
	blade_damage = 11.0
	player_speed = 310.0
	magnet_radius = 190.0
	crit_chance = 0.10
	boss_spawned = false
	boss_back.visible = false

	player.position = Vector2(_world_size().x * 0.5 - 29.0, _world_size().y * 0.54 - 29.0)

	for i in range(4):
		_add_blade(TAU * float(i) / 4.0)

func _update_hud() -> void:
	level_label.text = "LV %d" % level
	kills_label.text = "KILL %d" % kills

	var minutes := int(elapsed / 60.0)
	var seconds := int(elapsed) % 60
	timer_label.text = "%02d:%02d" % [minutes, seconds]

	hp_fill.size.x = 260.0 * clamp(hp / max_hp, 0.0, 1.0)
	xp_fill.size.x = 187.0 * clamp(float(xp) / float(max(1, xp_need)), 0.0, 1.0)

func _set_default_joystick() -> void:
	var screen_h := root.size.y
	joystick_center = Vector2(100.0, screen_h - BOTTOM_H - 105.0)
	joystick_pos = joystick_center
	joy_base.position = joystick_center - joy_base.size * 0.5
	joy_knob.position = joystick_center - joy_knob.size * 0.5

func _input(event: InputEvent) -> void:
	if choosing_upgrade:
		return

	if event is InputEventScreenTouch:
		if event.pressed:
			if event.position.x < root.size.x * 0.48 and event.position.y > root.size.y * 0.55:
				touch_id = event.index
				joystick_active = true
				joystick_center = event.position
				joystick_pos = event.position
				joy_base.position = joystick_center - joy_base.size * 0.5
				joy_knob.position = joystick_center - joy_knob.size * 0.5
		elif event.index == touch_id:
			touch_id = -1
			joystick_active = false
			_set_default_joystick()

	elif event is InputEventScreenDrag and event.index == touch_id:
		joystick_pos = joystick_center + (event.position - joystick_center).limit_length(76.0)
		joy_knob.position = joystick_pos - joy_knob.size * 0.5
