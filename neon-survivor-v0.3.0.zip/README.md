# Neon Survivor v0.3.0

Bu sürüm, çalışan v0.2.0 temelinin üstüne görsel kalite ve gerçek roguelite oynanış ekler.

Eklenenler:
- SVG tabanlı gerçek karakter sprite'ı
- Spider / Drone / Brute düşmanları
- 45. saniyede ilk boss
- Neon arena zemini
- Enerji bıçağı sprite'ları
- XP kristalleri
- Hasar rakamları
- Kritik vuruşlar
- Patlama / hit parçacıkları
- Düşman HP barları
- Boss HP barı
- Level-up ekranında 3 seçenek
- 6 farklı upgrade
- Daha modern HUD
- Uzun telefon ekranına uyum

GitHub Actions artık çalıştığı için workflow dosyasını değiştirmeyin.
Sadece eski oyun ZIP'ini bu ZIP ile değiştirin.
