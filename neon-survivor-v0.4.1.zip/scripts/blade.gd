extends Area2D

signal hit_landed(world_position, amount, critical)

var player_ref = null
var orbit_angle = 0.0
var orbit_radius = 108.0
var angular_speed = 2.9
var damage = 11.0
var crit_chance = 0.10
var sprite

var blade_texture = preload("res://assets/blade.svg")

func setup(player_node, start_angle):
	player_ref = player_node
	orbit_angle = start_angle

func _ready():
	sprite = Sprite2D.new()
	sprite.texture = blade_texture
	sprite.scale = Vector2(0.72, 0.72)
	add_child(sprite)
	body_entered.connect(_on_body_entered)

func _physics_process(delta):
	if player_ref == null or not is_instance_valid(player_ref):
		return

	orbit_angle += angular_speed * delta
	global_position = player_ref.global_position + Vector2(cos(orbit_angle), sin(orbit_angle)) * orbit_radius
	rotation = orbit_angle + PI * 0.5

func _on_body_entered(body):
	if body.has_method("take_damage"):
		var critical = randf() < crit_chance
		var amount = damage * (2.0 if critical else 1.0)
		var applied = body.take_damage(amount)
		if applied:
			hit_landed.emit(global_position, amount, critical)
