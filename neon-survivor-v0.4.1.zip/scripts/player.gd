extends CharacterBody2D

signal hp_changed(current_hp, max_hp)
signal died

var arena_size = Vector2(696.0, 1022.0)
var move_input = Vector2.ZERO
var speed = 310.0
var hp = 100.0
var max_hp = 100.0

var sprite
var frames

var tex_idle_a = preload("res://assets/player_idle_a.svg")
var tex_idle_b = preload("res://assets/player_idle_b.svg")
var tex_run_a = preload("res://assets/player_run_a.svg")
var tex_run_b = preload("res://assets/player_run_b.svg")

func _ready():
	_build_animation()

func _build_animation():
	sprite = AnimatedSprite2D.new()
	sprite.name = "AnimatedSprite2D"
	sprite.scale = Vector2(0.95, 0.95)
	add_child(sprite)

	frames = SpriteFrames.new()
	frames.add_animation("idle")
	frames.set_animation_speed("idle", 4.0)
	frames.set_animation_loop("idle", true)
	frames.add_frame("idle", tex_idle_a)
	frames.add_frame("idle", tex_idle_b)

	frames.add_animation("run")
	frames.set_animation_speed("run", 8.0)
	frames.set_animation_loop("run", true)
	frames.add_frame("run", tex_run_a)
	frames.add_frame("run", tex_run_b)

	sprite.sprite_frames = frames
	sprite.play("idle")

func set_move_input(value):
	move_input = value

func set_arena_size(value):
	arena_size = value

func _physics_process(_delta):
	velocity = move_input.limit_length(1.0) * speed
	move_and_slide()

	position.x = clamp(position.x, 28.0, arena_size.x - 28.0)
	position.y = clamp(position.y, 28.0, arena_size.y - 28.0)

	if velocity.length() > 5.0:
		if sprite.animation != "run":
			sprite.play("run")
		if velocity.x != 0.0:
			sprite.flip_h = velocity.x < 0.0
	else:
		if sprite.animation != "idle":
			sprite.play("idle")

func take_damage(amount):
	hp = max(0.0, hp - amount)
	hp_changed.emit(hp, max_hp)
	if hp <= 0.0:
		died.emit()

func heal(amount):
	hp = min(max_hp, hp + amount)
	hp_changed.emit(hp, max_hp)

func add_max_hp(amount):
	max_hp += amount
	hp += amount
	hp_changed.emit(hp, max_hp)

func reset_player():
	hp = 100.0
	max_hp = 100.0
	speed = 310.0
	hp_changed.emit(hp, max_hp)
