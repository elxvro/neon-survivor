# Neon Survivor v0.4.1 — Gameplay Runtime Fix

v0.4.0 açılıyor ama oynanış başlamıyorsa bu sürümü kullanın.

Düzeltme:
- `main.gd` içindeki riskli/yanlış NodePath ifadesi kaldırıldı.
- Root gameplay scriptinin parse edilmesini engelleyebilecek satır temizlendi.
- Oyun açılır açılmaz 1 düşman doğar.
- Sağ üst durum yazısı canlı olarak `2D LIVE • N ENEMY` gösterir.
- Timer ilerliyorsa, düşman sayısı değişiyorsa ve bıçaklar dönüyorsa gameplay scripti aktiftir.
- Mevcut çalışan GitHub Actions workflow'una dokunmayın.

Beklenen açılış:
1. Timer hemen ilerler.
2. İlk düşman anında görünür ve oyuncuya yaklaşır.
3. Dört enerji bıçağı oyuncunun etrafında döner.
4. Sol-alt joystick ile CharacterBody2D oyuncu hareket eder.
5. Bıçak düşmana değince hasar rakamı görünür.
