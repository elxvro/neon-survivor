extends Node2D

const SCREEN_W := 720.0
const SCREEN_H := 1280.0
const ARENA_TOP := 120.0
const ARENA_BOTTOM := 1120.0

var player := Vector2(SCREEN_W * 0.5, 690.0)
var player_radius := 22.0
var player_speed := 290.0
var player_hp := 100.0
var player_max_hp := 100.0
var invuln := 0.0

var enemies: Array[Dictionary] = []
var gems: Array[Dictionary] = []
var blades: Array[Dictionary] = []
var damage_numbers: Array[Dictionary] = []
var particles: Array[Dictionary] = []

var elapsed := 0.0
var spawn_acc := 0.0
var kill_count := 0
var coins := 0
var level := 1
var xp := 0
var xp_need := 8
var game_over := false
var paused_game := false

var joy_origin := Vector2.ZERO
var joy_current := Vector2.ZERO
var joy_active := false
var joy_touch_id := -1

var font := ThemeDB.fallback_font

func _ready() -> void:
	for i in range(4):
		blades.append({"angle": TAU * float(i) / 4.0})
	set_process(true)
	queue_redraw()

func _process(delta: float) -> void:
	if paused_game or game_over:
		queue_redraw()
		return

	elapsed += delta
	invuln = max(0.0, invuln - delta)
	spawn_acc += delta

	var spawn_delay := max(0.24, 0.9 - elapsed * 0.004)
	while spawn_acc >= spawn_delay:
		spawn_acc -= spawn_delay
		_spawn_enemy()

	_move_player(delta)
	_update_enemies(delta)
	_update_gems(delta)
	_update_blades(delta)
	_update_fx(delta)
	queue_redraw()

func _move_player(delta: float) -> void:
	var dir := Input.get_vector("move_left", "move_right", "move_up", "move_down")
	if joy_active:
		var joy_vec := (joy_current - joy_origin) / 75.0
		if joy_vec.length() > 0.15:
			dir = joy_vec.limit_length(1.0)

	player += dir * player_speed * delta
	player.x = clamp(player.x, 34.0, SCREEN_W - 34.0)
	player.y = clamp(player.y, ARENA_TOP + 34.0, ARENA_BOTTOM - 34.0)

func _spawn_enemy() -> void:
	var side := randi() % 4
	var p := Vector2.ZERO
	match side:
		0:
			p = Vector2(randf_range(0, SCREEN_W), ARENA_TOP - 35)
		1:
			p = Vector2(SCREEN_W + 35, randf_range(ARENA_TOP, ARENA_BOTTOM))
		2:
			p = Vector2(randf_range(0, SCREEN_W), ARENA_BOTTOM + 35)
		_:
			p = Vector2(-35, randf_range(ARENA_TOP, ARENA_BOTTOM))

	var roll := randf()
	var kind := 0
	var radius := 18.0
	var hp := 18.0 + elapsed * 0.08
	var speed := 78.0 + elapsed * 0.07
	if roll > 0.83:
		kind = 1
		radius = 29.0
		hp *= 3.4
		speed *= 0.58
	elif roll > 0.60:
		kind = 2
		radius = 14.0
		hp *= 0.7
		speed *= 1.35

	enemies.append({
		"pos": p,
		"hp": hp,
		"max_hp": hp,
		"radius": radius,
		"speed": speed,
		"kind": kind,
		"hit_cd": 0.0,
		"flash": 0.0
	})

func _update_enemies(delta: float) -> void:
	for i in range(enemies.size() - 1, -1, -1):
		var e := enemies[i]
		var d: Vector2 = player - e.pos
		if d.length() > 1.0:
			e.pos += d.normalized() * e.speed * delta
		e.hit_cd = max(0.0, e.hit_cd - delta)
		e.flash = max(0.0, e.flash - delta)

		if e.pos.distance_to(player) < e.radius + player_radius:
			if invuln <= 0.0:
				player_hp -= 12.0 if e.kind != 1 else 20.0
				invuln = 0.6
				_burst(player, 12, Color(1.0, 0.25, 0.3))
				if player_hp <= 0.0:
					game_over = true
			var push := (e.pos - player).normalized()
			e.pos += push * 18.0
		enemies[i] = e

func _update_blades(delta: float) -> void:
	var orbit := 112.0
	for b in blades:
		b.angle += delta * 2.7

	for ei in range(enemies.size() - 1, -1, -1):
		var e := enemies[ei]
		for b in blades:
			var bp := player + Vector2(cos(b.angle), sin(b.angle)) * orbit
			if bp.distance_to(e.pos) < e.radius + 18.0 and e.hit_cd <= 0.0:
				var dmg := 9.0 + level * 1.2
				e.hp -= dmg
				e.hit_cd = 0.18
				e.flash = 0.08
				damage_numbers.append({"pos": e.pos, "value": int(dmg), "life": 0.65})
				_burst(e.pos, 5, Color(0.45, 0.8, 1.0))
				break
		if e.hp <= 0.0:
			_on_enemy_killed(e)
			enemies.remove_at(ei)
		else:
			enemies[ei] = e

func _on_enemy_killed(e: Dictionary) -> void:
	kill_count += 1
	if randi() % 4 == 0:
		coins += 1
	var amount := 3 if e.kind == 1 else 1
	gems.append({"pos": e.pos, "value": amount, "phase": randf() * TAU})
	_burst(e.pos, 14 if e.kind == 1 else 8, Color(1.0, 0.25, 0.15))

func _update_gems(delta: float) -> void:
	for i in range(gems.size() - 1, -1, -1):
		var g := gems[i]
		g.phase += delta * 3.0
		var dist := g.pos.distance_to(player)
		if dist < 170.0:
			var s := lerp(110.0, 420.0, 1.0 - dist / 170.0)
			g.pos = g.pos.move_toward(player, s * delta)
		if dist < 28.0:
			xp += g.value
			gems.remove_at(i)
			_check_level_up()
		else:
			gems[i] = g

func _check_level_up() -> void:
	while xp >= xp_need:
		xp -= xp_need
		level += 1
		xp_need = int(round(xp_need * 1.28 + 2.0))
		player_max_hp += 4.0
		player_hp = min(player_max_hp, player_hp + 12.0)
		player_speed += 3.0
		if level == 4 and blades.size() < 5:
			blades.append({"angle": 0.0})
		if level == 7 and blades.size() < 6:
			blades.append({"angle": PI})
		_burst(player, 28, Color(0.3, 1.0, 0.85))

func _burst(pos: Vector2, count: int, color: Color) -> void:
	for n in count:
		var a := randf() * TAU
		var sp := randf_range(50.0, 190.0)
		particles.append({
			"pos": pos,
			"vel": Vector2(cos(a), sin(a)) * sp,
			"life": randf_range(0.18, 0.55),
			"color": color
		})

func _update_fx(delta: float) -> void:
	for i in range(damage_numbers.size() - 1, -1, -1):
		damage_numbers[i].life -= delta
		damage_numbers[i].pos.y -= 52.0 * delta
		if damage_numbers[i].life <= 0.0:
			damage_numbers.remove_at(i)

	for i in range(particles.size() - 1, -1, -1):
		particles[i].life -= delta
		particles[i].pos += particles[i].vel * delta
		particles[i].vel *= 0.92
		if particles[i].life <= 0.0:
			particles.remove_at(i)

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			if event.position.y < 110.0 and event.position.x > 620.0:
				paused_game = not paused_game
				return
			if event.position.y > 930.0 and event.position.x < 360.0:
				joy_active = true
				joy_touch_id = event.index
				joy_origin = event.position
				joy_current = event.position
		elif event.index == joy_touch_id:
			joy_active = false
			joy_touch_id = -1

	elif event is InputEventScreenDrag and event.index == joy_touch_id:
		joy_current = joy_origin + (event.position - joy_origin).limit_length(75.0)

	elif event is InputEventMouseButton:
		if event.pressed and event.position.y < 110.0 and event.position.x > 620.0:
			paused_game = not paused_game
		elif event.pressed and (game_over):
			_restart()

	if event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		paused_game = not paused_game

func _restart() -> void:
	player = Vector2(SCREEN_W * 0.5, 690.0)
	player_hp = 100.0
	player_max_hp = 100.0
	player_speed = 290.0
	enemies.clear()
	gems.clear()
	damage_numbers.clear()
	particles.clear()
	blades.clear()
	for i in range(4):
		blades.append({"angle": TAU * float(i) / 4.0})
	elapsed = 0.0
	spawn_acc = 0.0
	kill_count = 0
	coins = 0
	level = 1
	xp = 0
	xp_need = 8
	game_over = false
	paused_game = false

func _draw() -> void:
	_draw_background()
	_draw_hud()
	_draw_gems()
	_draw_enemies()
	_draw_player()
	_draw_blades()
	_draw_fx()
	_draw_joystick()

	if paused_game:
		draw_rect(Rect2(0, 0, SCREEN_W, SCREEN_H), Color(0,0,0,0.55))
		_center_text("DURAKLATILDI", Vector2(SCREEN_W/2, SCREEN_H/2), 36, Color.WHITE)
	elif game_over:
		draw_rect(Rect2(0, 0, SCREEN_W, SCREEN_H), Color(0,0,0,0.68))
		_center_text("OYUN BİTTİ", Vector2(SCREEN_W/2, 510), 44, Color.WHITE)
		_center_text("Skor: %d" % kill_count, Vector2(SCREEN_W/2, 575), 28, Color(0.7,0.9,1))
		_center_text("Tekrar başlamak için dokun", Vector2(SCREEN_W/2, 635), 22, Color(0.85,0.85,0.9))

func _draw_background() -> void:
	draw_rect(Rect2(0, 0, SCREEN_W, SCREEN_H), Color("#090d1f"))
	draw_rect(Rect2(0, ARENA_TOP, SCREEN_W, ARENA_BOTTOM-ARENA_TOP), Color("#12172b"))
	for x in range(0, 721, 90):
		draw_line(Vector2(x, ARENA_TOP), Vector2(x, ARENA_BOTTOM), Color(0.18,0.24,0.38,0.35), 1.0)
	for y in range(int(ARENA_TOP), int(ARENA_BOTTOM)+1, 90):
		draw_line(Vector2(0, y), Vector2(SCREEN_W, y), Color(0.18,0.24,0.38,0.35), 1.0)
	draw_circle(Vector2(SCREEN_W/2, 650), 180, Color(0.15,0.08,0.25,0.18))
	draw_arc(Vector2(SCREEN_W/2, 650), 180, 0, TAU, 96, Color(0.55,0.15,0.9,0.32), 3.0)

func _draw_hud() -> void:
	draw_rect(Rect2(0, 0, SCREEN_W, 120), Color(0.025,0.035,0.08,0.96))
	draw_string(font, Vector2(24, 40), "LV %d" % level, HORIZONTAL_ALIGNMENT_LEFT, -1, 26, Color(0.55,0.9,1))
	var xp_ratio := float(xp) / float(max(1, xp_need))
	draw_rect(Rect2(105, 22, 220, 18), Color(0.12,0.17,0.28))
	draw_rect(Rect2(105, 22, 220*xp_ratio, 18), Color(0.2,0.9,1))
	var mins := int(elapsed) / 60
	var secs := int(elapsed) % 60
	_center_text("%02d:%02d" % [mins, secs], Vector2(365, 48), 32, Color.WHITE)
	draw_string(font, Vector2(500, 40), "☠ %d" % kill_count, HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color.WHITE)
	draw_string(font, Vector2(590, 40), "◉ %d" % coins, HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color(1,0.82,0.18))
	draw_rect(Rect2(650, 18, 48, 48), Color(0.08,0.12,0.2), true)
	draw_string(font, Vector2(662, 52), "Ⅱ", HORIZONTAL_ALIGNMENT_LEFT, -1, 26, Color.WHITE)

	# HP
	draw_rect(Rect2(22, 78, 260, 14), Color(0.18,0.09,0.12))
	draw_rect(Rect2(22, 78, 260 * clamp(player_hp/player_max_hp,0,1), 14), Color(0.2,0.95,0.45))
	draw_string(font, Vector2(294, 92), "%d/%d" % [int(player_hp), int(player_max_hp)], HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color(0.85,0.95,0.9))

	# bottom ability bar
	draw_rect(Rect2(0, 1120, SCREEN_W, 160), Color(0.025,0.035,0.08,0.96))
	for i in range(4):
		var r := Rect2(150 + i*105, 1150, 82, 82)
		draw_rect(r, Color(0.06,0.08,0.15), true)
		draw_rect(r, Color(0.35,0.35+0.1*i,0.8,0.9), false, 3)
		var labels = ["✦","◈","➤","+"]
		_center_text(labels[i], r.position + Vector2(41,53), 30, Color.WHITE)
	_center_text("Lv.%d" % max(1, min(5, level)), Vector2(191, 1260), 18, Color(0.9,0.9,0.95))

func _draw_player() -> void:
	var blink := invuln > 0.0 and int(invuln * 20.0) % 2 == 0
	if blink:
		return
	draw_circle(player, player_radius+10, Color(0.35,0.15,0.95,0.2))
	draw_circle(player, player_radius, Color(0.1,0.85,1.0))
	draw_circle(player + Vector2(0,-2), player_radius-7, Color(0.07,0.09,0.16))
	draw_polygon(PackedVector2Array([
		player + Vector2(-9,-11), player + Vector2(0,-22), player + Vector2(9,-11),
		player + Vector2(7,7), player + Vector2(0,13), player + Vector2(-7,7)
	]), PackedColorArray([Color(0.85,0.95,1)]))
	draw_line(player+Vector2(9,5), player+Vector2(28,-12), Color(0.2,0.9,1), 6)

func _draw_blades() -> void:
	var orbit := 112.0
	draw_arc(player, orbit, 0, TAU, 80, Color(0.7,0.2,1.0,0.45), 4.0)
	for b in blades:
		var bp := player + Vector2(cos(b.angle), sin(b.angle)) * orbit
		var tangent := Vector2(-sin(b.angle), cos(b.angle))
		var normal := tangent.orthogonal()
		var pts := PackedVector2Array([
			bp + tangent*22.0,
			bp - tangent*15.0 + normal*8.0,
			bp - tangent*9.0,
			bp - tangent*15.0 - normal*8.0
		])
		draw_polygon(pts, PackedColorArray([Color(0.35,0.85,1.0)]))
		draw_polyline(pts + PackedVector2Array([pts[0]]), Color.WHITE, 2.0)

func _draw_enemies() -> void:
	for e in enemies:
		var c := Color(1.0,0.25,0.22) if e.flash <= 0.0 else Color.WHITE
		if e.kind == 0:
			draw_circle(e.pos, e.radius, Color(0.08,0.09,0.14))
			for k in range(6):
				var a := TAU * k/6.0
				draw_line(e.pos + Vector2(cos(a),sin(a))*10, e.pos + Vector2(cos(a),sin(a))*28, Color(0.18,0.2,0.28), 5)
			draw_circle(e.pos, 7, c)
		elif e.kind == 1:
			draw_circle(e.pos, e.radius, Color(0.13,0.12,0.15))
			draw_circle(e.pos, e.radius-8, Color(0.22,0.18,0.18))
			draw_circle(e.pos, 10, Color(1.0,0.32,0.12))
		else:
			var tri := PackedVector2Array([
				e.pos + Vector2(0,-e.radius),
				e.pos + Vector2(e.radius,e.radius),
				e.pos + Vector2(-e.radius,e.radius)
			])
			draw_polygon(tri, PackedColorArray([Color(0.12,0.11,0.18)]))
			draw_polyline(tri + PackedVector2Array([tri[0]]), c, 3)
		var hp_ratio := clamp(e.hp/e.max_hp,0,1)
		draw_rect(Rect2(e.pos.x-22, e.pos.y-e.radius-14, 44, 5), Color(0.15,0.05,0.08))
		draw_rect(Rect2(e.pos.x-22, e.pos.y-e.radius-14, 44*hp_ratio, 5), Color(1.0,0.18,0.25))

func _draw_gems() -> void:
	for g in gems:
		var p: Vector2 = g.pos
		var s := 10.0 + sin(g.phase)*1.5
		var pts := PackedVector2Array([p+Vector2(0,-s),p+Vector2(s*0.7,0),p+Vector2(0,s),p+Vector2(-s*0.7,0)])
		draw_polygon(pts, PackedColorArray([Color(0.25,1.0,0.8)]))
		draw_polyline(pts + PackedVector2Array([pts[0]]), Color(0.75,1.0,1.0), 2)

func _draw_fx() -> void:
	for d in damage_numbers:
		var alpha := clamp(d.life/0.65,0,1)
		draw_string(font, d.pos, str(d.value), HORIZONTAL_ALIGNMENT_CENTER, 54, 18, Color(1.0,0.45,0.72,alpha))
	for p in particles:
		var alpha := clamp(p.life/0.55,0,1)
		var col: Color = p.color
		col.a = alpha
		draw_circle(p.pos, 3.0, col)

func _draw_joystick() -> void:
	var origin := joy_origin if joy_active else Vector2(100, 1010)
	var knob := joy_current if joy_active else origin
	draw_circle(origin, 58, Color(0.9,0.95,1.0,0.10))
	draw_arc(origin, 58, 0, TAU, 64, Color(0.8,0.9,1.0,0.28), 3)
	draw_circle(knob, 25, Color(0.8,0.9,1.0,0.22))

func _center_text(text: String, center: Vector2, size: int, color: Color) -> void:
	var w := font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x
	draw_string(font, Vector2(center.x - w/2.0, center.y), text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, color)
