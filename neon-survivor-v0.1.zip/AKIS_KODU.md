# NEON SURVIVOR — OYUN AKIŞ KODU

BAŞLAT
→ Ana sahneyi aç
→ Oyuncuyu arenanın merkez-alt kısmına yerleştir
→ 4 dönen bıçak oluştur
→ HP = 100
→ Level = 1
→ XP = 0
→ Süre = 00:00

HER FRAME
→ Oyuncu joystick / WASD girdisini oku
→ Oyuncuyu arena sınırlarında hareket ettir
→ Düşman doğma zamanını kontrol et
→ Düşmanları oyuncuya doğru yürüt
→ Dönen bıçakların konumunu güncelle
→ Bıçak-düşman çarpışmalarını kontrol et
→ Hasar uygula
→ Ölen düşmandan XP kristali düşür
→ Yakındaki XP kristallerini oyuncuya çek
→ XP toplanırsa XP barını artır
→ XP yeterliyse level artır
→ Düşman oyuncuya değerse HP azalt
→ HP <= 0 ise GAME OVER

DÜŞMAN DOĞUR
→ Arenanın 4 kenarından rastgele bir kenar seç
→ Rastgele düşman tipi seç:
   %60 örümcek
   %23 hızlı drone
   %17 ağır robot
→ Süre ilerledikçe HP ve hız artır
→ Düşmanı listeye ekle

BIÇAK SİSTEMİ
→ Bıçaklar oyuncunun etrafında sürekli dön
→ Düşmana temas ederse hasar ver
→ Kısa hit cooldown uygula
→ Hasar sayısını göster
→ Vuruş parçacığı üret

DÜŞMAN ÖLDÜ
→ Kill +1
→ XP kristali oluştur
→ Şanslıysa coin +1
→ Patlama parçacığı göster

XP TOPLA
→ Kristal oyuncuya 170px yaklaşırsa çekim başlat
→ Oyuncuya değerse XP ekle
→ XP eşiği dolarsa:
   Level +1
   Maksimum HP biraz artar
   HP biraz iyileşir
   Hareket hızı biraz artar
   Belirli levellerde yeni bıçak eklenir

GAME OVER
→ Oyun döngüsünü durdur
→ Skoru göster
→ Dokununca tüm değişkenleri sıfırla
→ Yeni oyunu başlat

V0.2 PLAN
→ Level-up sırasında oyunu dondur
→ 3 rastgele yetenek kartı göster
→ Oyuncu birini seçsin
→ Roket / yıldırım / drone / kalkan / kritik / hareket hızı ekle
→ 3. dakikada elit
→ 5. dakikada mini boss
→ 10. dakikada ana boss
