# Neon Survivor v0.1

Godot 4 tabanlı, dikey ekran mobil 2D arena-survival prototipi.

## Bu sürümde
- Mobil sanal joystick
- Klavyede WASD / ok tuşları
- Otomatik yakın dönen bıçak saldırısı
- 3 düşman tipi
- XP kristalleri ve seviye sistemi
- Can, kill, coin ve süre HUD'u
- Hasar sayıları ve parçacık efektleri
- Zamanla hızlanan spawn sistemi
- Pause
- Game Over + yeniden başlatma

## Bilgisayarda çalıştırma
1. Godot 4.3+ kur.
2. `project.godot` dosyasını içe aktar.
3. F6/F5 ile çalıştır.

## Android
Godot > Editor > Manage Export Templates ile export template kur.
Ardından Android SDK/JDK ayarlarını yapıp Android export preset üzerinden APK al.

## Kontrol
- Android: Sol alanda sürükle.
- PC: WASD / ok tuşları.
- Sağ üst: Pause.
- Game Over ekranında dokun: yeniden başlat.

## Sonraki sürüm önerisi
v0.2:
- 3 seçimli level-up paneli
- Roket
- Zincir yıldırım
- Drone
- Dash
- Elit düşman
- İlk boss
- Ses + titreşim + screen shake
