# Neon Survivor v0.1.8

Android export fix:
Godot's `project.godot` uses section-relative keys.

Correct under `[rendering]`:
`textures/vram_compression/import_etc2_astc=true`

This package includes the corrected project setting and a clean Godot 4.3 Android debug workflow.
