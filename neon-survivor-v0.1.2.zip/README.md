# Neon Survivor v0.1.2

Bu paket GitHub'a doğrudan yüklenmek için hazırlanmıştır.

## En önemli nokta

GitHub reposunun kökünde şu dosyalar görünmelidir:

- `project.godot`
- `export_presets.cfg`
- `scenes/`
- `scripts/`
- `.github/workflows/android-build.yml`

ZIP dosyasını tek dosya olarak repoya yüklemeyin. ZIP'i açın ve içindeki dosyaları repo köküne yükleyin.

## GitHub Actions

Workflow yolu:

`.github/workflows/android-build.yml`

Workflow:
- her push'ta çalışır,
- pull request'te çalışır,
- Actions ekranından `Run workflow` ile elle çalıştırılabilir,
- Android debug APK üretir,
- sonucu `Artifacts` bölümüne yükler.

## Kontrol

GitHub'da:
1. Repo > Actions
2. `Neon Survivor APK Build`
3. `Run workflow`
4. İşlem tamamlanınca `Artifacts`
5. `neon-survivor-v0.1.1-apk`

## Oyun

- Dikey mobil ekran
- Sol alt sanal joystick
- Otomatik dönen bıçaklar
- 3 düşman tipi
- XP kristalleri
- Level sistemi
- Can / kill / coin / süre HUD
- Game Over ve yeniden başlatma

## v0.1.2 GitHub Actions düzeltmesi
- Proje klasörünü otomatik bulur.
- `.godot` yazma izinlerini düzeltir.
- `export_presets.cfg` eksikse otomatik üretir.
- APK'yı artifact olarak yükler.
