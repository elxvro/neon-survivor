# Neon Survivor v0.5.0 — Combat & Feel Update

Çalışan v0.4.1 temelinin üstüne savaş hissi eklendi.

## Yeni
- Screen shake
- Oyuncu hasar alınca kısa invulnerability + blink
- Düşman hit flash
- Kritik vuruşta büyük sarı hasar
- Energy blade glow
- Kill combo sistemi
- Combo timeout
- Boss charge/dash paterni
- Haptic / vibration
- Yeni upgrade: Overdrive (+ blade rotation)
- Game Over ekranı
- Run sonucu: süre / kill / level / best combo
- Restart Run butonu

## Korunan sistemler
- CharacterBody2D oyuncu
- CharacterBody2D düşmanlar
- Area2D enerji bıçakları
- XP kristalleri
- 3 seçenekli level-up
- Spider / Drone / Brute
- 60. saniyede boss

GitHub Actions workflow'unu değiştirmeyin.
Sadece oyun ZIP'ini `neon-survivor-v0.5.0.zip` olarak yükleyip mevcut çalışan build'i çalıştırın.
