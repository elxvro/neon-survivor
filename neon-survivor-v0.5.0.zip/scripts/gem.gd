extends Area2D

signal collected(value)

var target = null
var value = 1
var magnet_radius = 190.0
var sprite

var gem_texture = preload("res://assets/gem.svg")

func setup(player_node, gem_amount, radius):
	target = player_node
	value = gem_amount
	magnet_radius = radius

func _ready():
	sprite = Sprite2D.new()
	sprite.texture = gem_texture
	sprite.scale = Vector2(0.62, 0.62)
	add_child(sprite)

	var tween = create_tween()
	tween.set_loops()
	tween.tween_property(sprite, "scale", Vector2(0.72, 0.72), 0.45)
	tween.tween_property(sprite, "scale", Vector2(0.62, 0.62), 0.45)

func _physics_process(delta):
	if target == null or not is_instance_valid(target):
		return

	var distance = global_position.distance_to(target.global_position)

	if distance < magnet_radius:
		global_position = global_position.move_toward(target.global_position, 420.0 * delta)

	if distance < 24.0:
		collected.emit(value)
		queue_free()
