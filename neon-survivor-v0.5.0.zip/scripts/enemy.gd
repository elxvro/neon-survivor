extends CharacterBody2D

signal died(enemy, world_position, gem_value, was_boss)
signal contact_damage(amount)
signal hp_ratio_changed(ratio, was_boss)

var target = null
var kind = 0
var max_hp = 20.0
var hp = 20.0
var speed = 80.0
var contact = 15.0
var gem_value = 1
var was_boss = false

var sprite
var health_back
var health_fill
var contact_clock = 0.0
var hit_lock = 0.0
var flash_time = 0.0

var boss_cycle = 0.0
var boss_charge_time = 0.0

var spider_a = preload("res://assets/spider_a.svg")
var spider_b = preload("res://assets/spider_b.svg")
var drone_a = preload("res://assets/drone_a.svg")
var drone_b = preload("res://assets/drone_b.svg")
var brute_a = preload("res://assets/brute_a.svg")
var brute_b = preload("res://assets/brute_b.svg")
var boss_a = preload("res://assets/boss_a.svg")
var boss_b = preload("res://assets/boss_b.svg")

func configure(enemy_kind, player_target, difficulty):
	kind = enemy_kind
	target = player_target

	if kind == 0:
		max_hp = 22.0 + difficulty * 1.4
		speed = 88.0 + difficulty * 0.35
		contact = 15.0
		gem_value = 1
	elif kind == 1:
		max_hp = 16.0 + difficulty * 1.0
		speed = 126.0 + difficulty * 0.45
		contact = 11.0
		gem_value = 1
	elif kind == 2:
		max_hp = 66.0 + difficulty * 3.0
		speed = 56.0 + difficulty * 0.18
		contact = 24.0
		gem_value = 3
	else:
		was_boss = true
		max_hp = 600.0 + difficulty * 8.0
		speed = 46.0
		contact = 34.0
		gem_value = 10

	hp = max_hp

func _ready():
	_build_visual()

func _build_visual():
	sprite = AnimatedSprite2D.new()
	var sf = SpriteFrames.new()
	sf.add_animation("move")
	sf.set_animation_loop("move", true)

	if kind == 0:
		sf.set_animation_speed("move", 7.0)
		sf.add_frame("move", spider_a)
		sf.add_frame("move", spider_b)
	elif kind == 1:
		sf.set_animation_speed("move", 9.0)
		sf.add_frame("move", drone_a)
		sf.add_frame("move", drone_b)
	elif kind == 2:
		sf.set_animation_speed("move", 5.0)
		sf.add_frame("move", brute_a)
		sf.add_frame("move", brute_b)
	else:
		sf.set_animation_speed("move", 4.0)
		sf.add_frame("move", boss_a)
		sf.add_frame("move", boss_b)

	sprite.sprite_frames = sf
	sprite.play("move")
	add_child(sprite)

	var shape = $CollisionShape2D.shape
	if kind == 0:
		sprite.scale = Vector2(0.72, 0.72)
		shape.radius = 18.0
	elif kind == 1:
		sprite.scale = Vector2(0.66, 0.66)
		shape.radius = 16.0
	elif kind == 2:
		sprite.scale = Vector2(1.0, 1.0)
		shape.radius = 27.0
	else:
		sprite.scale = Vector2(1.45, 1.45)
		shape.radius = 43.0

	health_back = ColorRect.new()
	health_back.position = Vector2(-30.0, -42.0 if not was_boss else -64.0)
	health_back.size = Vector2(60.0, 6.0)
	health_back.color = Color(0.20, 0.02, 0.05, 0.95)
	health_back.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(health_back)

	health_fill = ColorRect.new()
	health_fill.size = health_back.size
	health_fill.color = Color(1.0, 0.14, 0.24, 1.0)
	health_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	health_back.add_child(health_fill)

func _physics_process(delta):
	if target == null or not is_instance_valid(target):
		return

	hit_lock = max(0.0, hit_lock - delta)
	contact_clock = max(0.0, contact_clock - delta)
	flash_time = max(0.0, flash_time - delta)

	if sprite != null:
		sprite.modulate = Color(1.0, 0.45, 0.45, 1.0) if flash_time > 0.0 else Color.WHITE

	var speed_multiplier = 1.0

	if was_boss:
		boss_cycle += delta
		boss_charge_time = max(0.0, boss_charge_time - delta)

		if boss_cycle >= 3.2:
			boss_cycle = 0.0
			boss_charge_time = 0.62

		if boss_charge_time > 0.0:
			speed_multiplier = 2.35
			if sprite != null:
				sprite.scale = Vector2(1.58, 1.58)
		else:
			if sprite != null:
				sprite.scale = Vector2(1.45, 1.45)

	var delta_pos = target.global_position - global_position
	if delta_pos.length() > 2.0:
		velocity = delta_pos.normalized() * speed * speed_multiplier
	else:
		velocity = Vector2.ZERO

	move_and_slide()

	if delta_pos.length() < (58.0 if was_boss else 34.0) and contact_clock <= 0.0:
		contact_damage.emit(contact)
		contact_clock = 0.55

func take_damage(amount):
	if hit_lock > 0.0:
		return false

	hit_lock = 0.08
	flash_time = 0.08
	hp -= amount

	var ratio = clamp(hp / max_hp, 0.0, 1.0)

	if health_fill != null:
		health_fill.size.x = health_back.size.x * ratio

	hp_ratio_changed.emit(ratio, was_boss)

	if hp <= 0.0:
		died.emit(self, global_position, gem_value, was_boss)
		queue_free()

	return true
